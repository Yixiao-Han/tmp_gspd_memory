/**
 * Debug logging — appends timestamped sections to debug/*.md
 *
 * All output is gated by a global enabled flag.  Call `setDebugEnabled(true)`
 * once at plugin registration time (when cfg.debug is true).
 */

import { appendFile } from "node:fs/promises";
import { join } from "node:path";
import { homedir } from "node:os";

const DEBUG_DIR = join(homedir(), ".openclaw", "memory", "debug");
export const DEBUG_LOG = join(DEBUG_DIR, "inteSkill-debug.md");
export const PROMPT_DEBUG_LOG = join(DEBUG_DIR, "prompt-debug.md");
let debugEnabled = false;

export function setDebugEnabled(on: boolean): void {
  debugEnabled = on;
}

export async function debugLog(section: string, content: string): Promise<void> {
  if (!debugEnabled) return;
  const ts = new Date().toISOString();
  const sep = "=".repeat(60);
  const entry = `\n${sep}\n[${ts}] ${section}\n${sep}\n${content}\n`;
  try { await appendFile(DEBUG_LOG, entry, "utf8"); } catch { /* non-fatal */ }
}

export async function debugPrompt(query: string, rewrittenQuery: string, catalog: string): Promise<void> {
  if (!debugEnabled) return;
  const ts = new Date().toISOString();
  const sep = "=".repeat(60);
  const entry =
    `\n${sep}\n[${ts}] INJECTED SYSTEM CONTEXT\n${sep}\n` +
    `query:    ${query}\n` +
    `rewrite:  ${rewrittenQuery}\n\n` +
    `${catalog}\n`;
  try { await appendFile(PROMPT_DEBUG_LOG, entry, "utf8"); } catch { /* non-fatal */ }
}
