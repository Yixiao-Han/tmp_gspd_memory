/**
 * Debug logging — appends timestamped sections to inteSkill-debug.md
 */

import { appendFile } from "node:fs/promises";
import { join } from "node:path";
import { homedir } from "node:os";

export const DEBUG_LOG = join(homedir(), ".openclaw", "memory", "debug", "inteSkill-debug.md");
export const PROMPT_DEBUG_LOG = join(homedir(), ".openclaw", "memory", "debug", "prompt-debug.md");

export async function debugLog(section: string, content: string): Promise<void> {
  const ts = new Date().toISOString();
  const sep = "=".repeat(60);
  const entry = `\n${sep}\n[${ts}] ${section}\n${sep}\n${content}\n`;
  try { await appendFile(DEBUG_LOG, entry, "utf8"); } catch { /* non-fatal */ }
}

export async function debugPrompt(query: string, rewrittenQuery: string, catalog: string): Promise<void> {
  const ts = new Date().toISOString();
  const sep = "=".repeat(60);
  const entry =
    `\n${sep}\n[${ts}] INJECTED SYSTEM CONTEXT\n${sep}\n` +
    `query:    ${query}\n` +
    `rewrite:  ${rewrittenQuery}\n\n` +
    `${catalog}\n`;
  try { await appendFile(PROMPT_DEBUG_LOG, entry, "utf8"); } catch { /* non-fatal */ }
}
