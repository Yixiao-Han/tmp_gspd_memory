/**
 * Skill learning — single LLM pass extraction from agent messages.
 *
 * Replaces the old two-pass (cleanWorkflow + concludeSkill) + buffer approach.
 * Uses event.messages directly — no buffer persistence needed.
 * Only extracts kind=workflow (preference comes from Evaluate/Evolve).
 */

import { chatCompletion, type ChatConfig } from "./llm.js";
import {
  stripCodeFences,
  parseFrontmatter,
  isNegativeResponse,
  slugify,
  generateSkillId,
  headTailTruncate,
} from "./format.js";
import { debugLog } from "./debug.js";

// ---------------------------------------------------------------------------
// Build workflow text from messages (from old buffer.ts)
// ---------------------------------------------------------------------------

export function buildWorkflowText(messages: unknown[]): string {
  const parts: string[] = [];
  for (const msg of messages) {
    if (!msg || typeof msg !== "object") continue;
    const m = msg as Record<string, unknown>;
    const role = String(m.role || "unknown");
    if (role === "system") continue;
    const content = m.content;

    let text = "";
    if (typeof content === "string") {
      text = content;
    } else if (Array.isArray(content)) {
      text = (content as Record<string, unknown>[])
        .filter((b) => b && b.type === "text" && typeof b.text === "string")
        .map((b) => b.text as string)
        .join("\n");
    }

    text = text.trim();
    if (!text) continue;
    if (text.startsWith("A new session was started via /new") ||
        text.startsWith("Execute your Session Startup")) continue;

    parts.push(`[${role}]: ${text.slice(0, 3000)}`);
  }
  return parts.join("\n\n");
}

// ---------------------------------------------------------------------------
// Extract first user message
// ---------------------------------------------------------------------------

export function extractFirstUserMessage(messages: unknown[]): string {
  const parts: string[] = [];
  for (const msg of messages) {
    if (!msg || typeof msg !== "object") continue;
    const m = msg as Record<string, unknown>;
    if (m.role !== "user") continue;
    const c = m.content;
    let text = "";
    if (typeof c === "string") {
      text = c.trim();
    } else if (Array.isArray(c)) {
      for (const b of c) {
        const bl = b as Record<string, unknown>;
        if (bl.type === "text" && typeof bl.text === "string" && bl.text.trim()) {
          text = bl.text.trim();
          break;
        }
      }
    }
    if (!text) continue;
    // Skip system/session boilerplate
    if (text.startsWith("A new session was started") ||
        text.startsWith("Execute your Session Startup") ||
        text.startsWith("System:")) continue;
    // Strip skill injection and platform noise
    text = text
      .replace(/\*\*重要 — 必须使用技能\*\*[\s\S]*?(?=\n\[|$)/, "")
      .replace(/Sender \(untrusted metadata\):\s*```json\s*\{[^}]*\}\s*```\s*/g, "")
      .replace(/^\[[\w\s,]+\d{4}[-/]\d{2}[-/]\d{2}\s+\d{2}:\d{2}\s+GMT[^\]]*\]\s*/, "")
      .trim();
    if (!text) continue;
    parts.push(text);
  }
  return parts.join("\n");
}

// ---------------------------------------------------------------------------
// Single-pass LLM extraction prompt
// ---------------------------------------------------------------------------

const EXTRACT_SYSTEM = `你是一个技能提取助手，从 agent 工作流中提取标准化的可复用 workflow 操作卡片。

## 判断标准

提取（满足以下任一条件）：
- 工作流成功完成了具体任务，包含 2 步以上操作
- 领域特定的任务也应提取

拒绝（以下情况只输出 JSON）：
- 工作流未完成或中途失败
- 纯问答，无可操作步骤
- 只有单步操作且无判断逻辑
- 对话内容太少，无法提取有意义的技能

## SKILL.md 格式

值得提取时，直接输出卡片（不加代码块）：

---
name: <4-10汉字，动词+宾语>
description: <中文一句话，15-40字，在[场景]中[做什么][产出是什么]>
kind: workflow
---

## 触发条件
- <具体特征>

## 执行步骤
1. <步骤>（3-6步，具体到工具级别）

## 注意事项
- <常见失败点>

## 示例
输入："<用户原始请求>"
输出：<最终产出简述>

不值得提取时，只输出：
{"extracted": false, "reason": "<原因>"}`;

// ---------------------------------------------------------------------------
// extractSkill — single LLM call
// ---------------------------------------------------------------------------

export type ExtractionResult =
  | { extracted: true; skillId: string; name: string; slug: string; description: string; rawContent: string }
  | { extracted: false; reason: string };

export async function extractSkill(
  messages: unknown[],
  taskDescription: string,
  chat: ChatConfig,
): Promise<ExtractionResult> {
  const workflowText = buildWorkflowText(messages);
  if (workflowText.length < 200) {
    return { extracted: false, reason: `workflow too short (${workflowText.length} chars)` };
  }

  const userPrompt = `请判断并提取技能。不值得提取时只输出 JSON。

任务描述：${taskDescription || "（未知）"}

工作流：
---
${headTailTruncate(workflowText, 8000)}
---`;

  await debugLog("EXTRACT PROMPT", userPrompt);

  let raw: string;
  try {
    raw = await chatCompletion(chat, EXTRACT_SYSTEM, userPrompt, 30_000);
  } catch (err) {
    await debugLog("EXTRACT LLM ERROR", String(err));
    return { extracted: false, reason: `LLM error: ${String(err)}` };
  }

  await debugLog("EXTRACT RAW RESPONSE", raw);
  raw = stripCodeFences(raw);

  // Check for negative response
  const negative = isNegativeResponse(raw);
  if (negative) return negative;

  // Normalize JSON prefix edge case
  let normalizedRaw = raw;
  const jsonPrefixMatch = raw.match(/^\s*(\{[^}]*"extracted"\s*:\s*true[^}]*\})\s*(---[\s\S]*)?$/);
  if (jsonPrefixMatch) {
    const markdownPart = jsonPrefixMatch[2] || "";
    if (markdownPart.startsWith("---")) {
      normalizedRaw = markdownPart;
    }
  }

  // Parse frontmatter
  const { name, description } = parseFrontmatter(normalizedRaw);
  if (!name) {
    await debugLog("PARSE FAILED", `name empty, raw_start="${raw.slice(0, 200)}"`);
    return { extracted: false, reason: "LLM output missing name in frontmatter" };
  }

  const skillName = name.trim().replace(/\s+/g, "").slice(0, 20);
  if (!skillName) {
    return { extracted: false, reason: "Could not derive valid skill name" };
  }

  const slug = slugify(skillName);
  const skillId = generateSkillId();

  return {
    extracted: true,
    skillId,
    name: skillName,
    slug,
    description: description || "",
    rawContent: normalizedRaw,
  };
}
