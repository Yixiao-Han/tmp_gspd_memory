/**
 * inteSkill hooks — before_prompt_build (inject) + agent_end (learn)
 *
 * Thin plugin layer: all LLM logic, dedup, formatting, and event tracking
 * are handled by the C MCP server. Plugin only calls skill_search and skill_ingest.
 */

import type { OpenClawPluginApi } from "openclaw/plugin-sdk";
import type { GspdMcpClient } from "../core/client.js";
import type { GspdMemoryConfig } from "../core/config.js";
import { extractFirstUserMessage } from "./learn.js";
import { sanitizeUserTextForCapture } from "../memory/text-utils.js";
import { debugLog, debugPrompt } from "./debug.js";
import { isSkillInjectViaContext } from "../../../shared/gspd-client-singleton.js";

// Per-tool-result content limit for skill_ingest payload.
// user/assistant messages are kept intact; tool results from
// read/search/fetch can be very large (WebSearch etc.).
// 200 chars is enough for LearnSkill to understand the output.
const TOOL_RESULT_INGEST_MAX = 100;
const MSGS_LIMIT = 120_000;

// Strip metadata fields that waste LLM tokens but have no value
// for skill extraction (api, provider, model, usage, cost, etc.)
const STRIP_KEYS = new Set([
  "api", "provider", "model", "usage", "stopReason",
  "timestamp", "thinkingSignature", "details",
  "isError",
]);

// Prefixes in user messages that are platform boilerplate
const USER_NOISE_PREFIXES = [
  "A new session was started",
  "Execute your Session Startup",
  // Note: "Sender (untrusted metadata):" is NOT here — it's handled by
  // INJECTED_PATTERNS which strips just the Sender JSON block and preserves
  // the user's actual message text that follows it.
];

// Patterns injected by the platform into user messages
const INJECTED_PATTERNS = [
  // Skill injection block — greedy match to the LAST blank line (\n\n),
  // so the user's actual message after the injection block is preserved.
  // If no \n\n exists, the entire string is injection → remove all.
  /\*\*重要 — 必须使用技能\*\*(?:[\s\S]*\n\n|[\s\S]*$)/,
  // Sender metadata block
  /Sender \(untrusted metadata\):\s*```json\s*\{[^}]*\}\s*```\s*/g,
  // Timestamp prefix: [Sun 2026-03-29 15:57 GMT+8]
  /^\[[\w\s,]+\d{4}[-/]\d{2}[-/]\d{2}\s+\d{2}:\d{2}\s+GMT[^\]]*\]\s*/,
  // Memory recall injection blocks
  /<relevant-memories>[\s\S]*?<\/relevant-memories>\s*/g,
];

function stripInjectedNoise(text: string): string {
  let out = text;
  for (const pat of INJECTED_PATTERNS) {
    out = out.replace(pat, "");
  }
  return out.trim();
}

function stripMetadata(msgs: unknown[]): unknown[] {
  const result: unknown[] = [];
  for (const msg of msgs) {
    if (!msg || typeof msg !== "object") continue;
    const m = msg as Record<string, unknown>;

    // Drop empty toolResult "(no output)"
    if (m.role === "toolResult" || m.role === "tool") {
      const c = m.content;
      if (typeof c === "string" && c.trim() === "(no output)") continue;
      if (Array.isArray(c) && c.length === 1) {
        const bl = c[0] as Record<string, unknown>;
        if (bl?.type === "text" && typeof bl.text === "string"
            && bl.text.trim() === "(no output)") continue;
      }
    }

    // Drop session startup user messages
    if (m.role === "user") {
      const text = extractText(m.content);
      if (text && USER_NOISE_PREFIXES.some((p) => text.startsWith(p))) continue;
    }

    // Strip metadata keys + clean content blocks
    const cleaned: Record<string, unknown> = {};
    for (const [k, v] of Object.entries(m)) {
      if (STRIP_KEYS.has(k)) continue;
      if (k === "content" && Array.isArray(v)) {
        cleaned[k] = v.map((b) => {
          if (!b || typeof b !== "object") return b;
          const bl = b as Record<string, unknown>;
          const { thinkingSignature: _, ...rest } = bl;
          // Clean injected noise from text blocks
          if (rest.type === "text" && typeof rest.text === "string") {
            rest.text = stripInjectedNoise(rest.text as string);
          }
          return rest;
        }).filter((b) => {
          // Drop empty text blocks after cleaning
          if (b && typeof b === "object") {
            const bl = b as Record<string, unknown>;
            if (bl.type === "text" && typeof bl.text === "string" && !bl.text.trim()) return false;
          }
          return true;
        });
      } else {
        cleaned[k] = v;
      }
    }
    result.push(cleaned);
  }
  return result;
}

function extractText(content: unknown): string {
  if (typeof content === "string") return content.trim();
  if (Array.isArray(content)) {
    for (const b of content) {
      if (b && typeof b === "object") {
        const bl = b as Record<string, unknown>;
        if (bl.type === "text" && typeof bl.text === "string") return bl.text.trim();
      }
    }
  }
  return "";
}

function trimToolResults(msgs: unknown[]): unknown[] {
  return msgs.map((msg) => {
    const m = msg as Record<string, unknown>;
    if (m.role !== "tool" && m.role !== "toolResult") return m;
    const content = m.content;
    if (typeof content === "string" && content.length > TOOL_RESULT_INGEST_MAX) {
      return { ...m, content: content.slice(0, TOOL_RESULT_INGEST_MAX) + "\n…[截断]" };
    }
    if (Array.isArray(content)) {
      return {
        ...m,
        content: content.map((b) => {
          if (!b || typeof b !== "object") return b;
          const bl = b as Record<string, unknown>;
          if (bl.type === "text" && typeof bl.text === "string" && bl.text.length > TOOL_RESULT_INGEST_MAX) {
            return { ...bl, text: (bl.text as string).slice(0, TOOL_RESULT_INGEST_MAX) + "\n…[截断]" };
          }
          return bl;
        }),
      };
    }
    return m;
  });
}

// ============================================================================
// Skill inject hook — before_prompt_build
// ============================================================================

export function registerSkillInject(
  api: OpenClawPluginApi,
  client: GspdMcpClient,
  cfg: GspdMemoryConfig,
): void {
  api.on("before_prompt_build", async (event, ctx) => {
    if (isSkillInjectViaContext()) {
      // Skill inject is handled by context engine assemble()
      return;
    }

    await debugLog("SKILL before_prompt_build FIRED", `event keys: ${Object.keys(event).join(", ")}`);

    const eventMessages = (event.messages as unknown[]) || [];
    let rawQuery: string =
      ((event as Record<string, unknown>).query as string) ||
      ((event as Record<string, unknown>).prompt as string) ||
      extractFirstUserMessage(eventMessages);
    // Strip previously-injected skill prompt that may leak into
    // event.query/prompt on subsequent turns.
    rawQuery = rawQuery
      .replace(/\*\*重要 — 必须使用技能\*\*[\s\S]*?不需要注明。\s*/g, "")
      .replace(/\*\*重要 — 必须使用技能\*\*[\s\S]*$/g, "")
      .replace(/<relevant-memories>[\s\S]*?<\/relevant-memories>\s*/g, "")
      .trim();
    const query = sanitizeUserTextForCapture(rawQuery);
    const sessionId: string | undefined = ctx?.sessionKey;

    if (!query || query.length < 5) {
      await debugLog("SKILL before_prompt_build SKIP", "query too short or empty");
      return;
    }

    if (!client.isConnected() && !(await client.waitReady())) {
      api.logger.warn?.("inteSkill: skill search skipped — server not ready");
      return;
    }

    try {
      // C server handles: hybrid search + normScore filtering + inject_count + INJECTED events + catalog format
      const result = (await client.callTool("skill_search", {
        query,
        topK: cfg.topK,
        topKExperience: cfg.topKExperience,
        minScore: cfg.minScore,
        status: "active",
        ...(sessionId ? { sessionId } : {}),
      })) as { catalog: string; count: number; rewritten_query?: string; results: Array<{ name: string; kind?: string; norm_score?: number }> };

      await debugLog(
        "SKILL before_prompt_build SEARCH",
        `topK=${cfg.topK} minScore=${cfg.minScore} count=${result.count}`,
      );

      if (!result.catalog || result.count === 0) {
        api.logger.info(`inteSkill: no matching skills above minScore`);
        return;
      }

      const workflows = (result.results ?? []).filter((r) => r.kind !== "experience");
      const experiences = (result.results ?? []).filter((r) => r.kind === "experience");
      const fmtList = (items: typeof workflows) =>
        items.map((r) => `"${r.name}"(${(r.norm_score ?? 0).toFixed(2)})`).join(", ");
      if (workflows.length > 0)
        api.logger.info(`inteSkill: injecting ${workflows.length} workflow(s): ${fmtList(workflows)}`);
      if (experiences.length > 0)
        api.logger.info(`inteSkill: injecting ${experiences.length} experience(s): ${fmtList(experiences)}`);

      const systemContext =
        `**重要 — 必须使用技能**：以下技能已与当前任务匹配。` +
        `浏览下方描述，如有明确适用的技能，立即使用 Read 工具读取其 SKILL.md 并严格按照步骤执行。` +
        `若多个技能均可能适用，选择最具体的那个，读取并严格执行。` +
        `不得跳过技能中定义的步骤，不得自行发挥。\n` +
        `**使用技能后，在回复末尾注明**：「✅ 已使用技能：<技能名称>」。` +
        `如果没有使用任何技能，不需要注明。\n\n` +
        `${result.catalog}`;

      await debugPrompt(query, result.rewritten_query ?? query, systemContext);
      return { prependContext: systemContext };
    } catch (err) {
      api.logger.warn(`inteSkill: skill search failed: ${String(err)}`);
    }
  });
}

// ============================================================================
// Skill learn hook — agent_end
// ============================================================================

export function registerSkillLearn(
  api: OpenClawPluginApi,
  client: GspdMcpClient,
  cfg: GspdMemoryConfig,
): void {
  api.on("agent_end", async (event, ctx) => {
    const allMessages = (event.messages as unknown[]) || [];
    if (allMessages.length === 0) return;

    // taskDescription 由 C 层从 messagesJson 提取
    const taskDescription = "";

    const success = (event.success as boolean) === true;
    const sessionId: string | undefined = ctx?.sessionKey;

    if (!client.isConnected() && !(await client.waitReady())) {
      api.logger.warn?.("inteSkill: skill_ingest skipped — server not ready");
      return;
    }

    api.logger.info(`inteSkill: agent_end — delegating to skill_ingest (${allMessages.length} msgs, success=${success})`);

    try {
      // C server handles: cursor lookup, message slicing, AnalyzeTaskBoundary,
      // ScanMessagesForSkillRead, LearnSkill LLM, Dedup pipeline, all events.
      // Plugin passes full messages; C layer slices from task_start automatically.
      // Strip useless metadata, truncate tool results,
      // then drop oldest messages if still over limit.
      let msgsToSend = trimToolResults(
        stripMetadata(allMessages));
      let messagesJson = JSON.stringify(msgsToSend);
      while (messagesJson.length > MSGS_LIMIT && msgsToSend.length > 1) {
        msgsToSend = msgsToSend.slice(1);
        messagesJson = JSON.stringify(msgsToSend);
      }
      const result = (await client.callTool("skill_ingest", {
        messagesJson,
        taskDescription: taskDescription?.slice(0, 500) || "",
        tailTurns: cfg.tailTurns ?? 5,
        dedupThreshold: cfg.dedupThreshold ?? 0.55,
        success,
        ...(sessionId ? { sessionId } : {}),
      }, 180_000)) as { action: string; reason?: string; skillId?: string; name?: string };

      await debugLog("SKILL LEARN RESULT", JSON.stringify(result));
      const r = result as Record<string, unknown>;
      const extras: string[] = [];
      if (r.debug_status != null) extras.push(`st=${r.debug_status} ext=${r.debug_extracted}`);
      if (r.used != null) {
        const names = Array.isArray(r.used_names) && r.used_names.length > 0
          ? ` names=${(r.used_names as string[]).map(n => `"${n}"`).join(",")}`
          : "";
        extras.push(`used=${r.used}${names}`);
      }
      const steps = (r.steps as string) || "";
      api.logger.info(`inteSkill: skill_ingest → ${result.action}${result.name ? ` "${result.name}"` : ""}${result.reason ? ` (${result.reason})` : ""}${steps ? ` [${steps}]` : ""}`);
    } catch (err) {
      api.logger.warn(`inteSkill: skill_ingest failed: ${String(err)}`);
    }
  });
}
