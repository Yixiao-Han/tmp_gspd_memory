/**
 * LLM chat completion via fetch — OpenAI-compatible API
 */

export type ChatConfig = {
  baseUrl: string;
  apiKey: string;
  model: string;
};

function chatEndpoint(baseUrl: string): string {
  const base = baseUrl.replace(/\/+$/, "");
  if (base.endsWith("/v1")) return `${base}/chat/completions`;
  return `${base}/v1/chat/completions`;
}

export async function chatCompletion(
  cfg: ChatConfig,
  systemPrompt: string,
  userMessage: string,
  timeoutMs = 60_000,
): Promise<string> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const resp = await fetch(chatEndpoint(cfg.baseUrl), {
      method: "POST",
      signal: controller.signal,
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${cfg.apiKey}`,
      },
      body: JSON.stringify({
        model: cfg.model,
        messages: [
          { role: "system", content: systemPrompt },
          { role: "user",   content: userMessage },
        ],
        temperature: 0.2,
        max_tokens: 1024,
      }),
    });

    if (!resp.ok) {
      const body = await resp.text().catch(() => "");
      throw new Error(`LLM HTTP ${resp.status}: ${body.slice(0, 200)}`);
    }

    const data = (await resp.json()) as {
      choices?: Array<{ message?: { content?: string } }>;
    };
    const choices = data.choices;
    const msg = choices && choices[0] && choices[0].message;
    const content = (msg && msg.content && msg.content.trim()) || "";
    return content;
  } finally {
    clearTimeout(timer);
  }
}
