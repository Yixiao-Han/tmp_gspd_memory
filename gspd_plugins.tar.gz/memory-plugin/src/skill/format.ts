/**
 * SKILL.md parsing, formatting, and text utilities
 */

// ---------------------------------------------------------------------------
// Text cleanup
// ---------------------------------------------------------------------------

/** Strip <think>...</think> blocks and markdown code fences */
export function stripCodeFences(text: string): string {
  let out = text.replace(/<think>[\s\S]*?<\/think>/gi, "").trim();
  out = out.replace(/^```(?:markdown)?\s*\n([\s\S]*?)\n```\s*$/m, "$1").trim();
  return out;
}

// ---------------------------------------------------------------------------
// Frontmatter parsing
// ---------------------------------------------------------------------------

export function parseFrontmatter(md: string): { name: string; description: string; body: string } {
  const trimmed = md.trim();

  const bodyMatch = trimmed.match(/(##[\s\S]*)/);
  const body = bodyMatch ? bodyMatch[1].trim() : trimmed;

  const nameMatch = trimmed.match(/^name:\s*(.+)$/m);
  const descMatch = trimmed.match(/^description:\s*(.+)$/m);

  const rawName = nameMatch && nameMatch[1];
  const rawDesc = descMatch && descMatch[1];

  return {
    name:        (rawName && rawName.trim()) || "",
    description: (rawDesc && rawDesc.trim()) || "",
    body,
  };
}


// ---------------------------------------------------------------------------
// Negative response detection
// ---------------------------------------------------------------------------

/** Check if LLM output is a rejection JSON like {"extracted": false, "reason": "..."} */
export function isNegativeResponse(text: string): { extracted: false; reason: string } | null {
  try {
    const parsed = JSON.parse(text) as Record<string, unknown>;
    if (parsed.extracted === false) {
      return { extracted: false, reason: String(parsed.reason || "not generalizable") };
    }
  } catch { /* not JSON */ }
  return null;
}

// ---------------------------------------------------------------------------
// Slug generation
// ---------------------------------------------------------------------------

export function slugify(name: string): string {
  return name
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s_-]/gu, "")
    .replace(/[\s_]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60);
}

// ---------------------------------------------------------------------------
// Skill ID generation — stable UUID: sk_<8hex>
// ---------------------------------------------------------------------------

export function generateSkillId(): string {
  const hex = Array.from({ length: 8 }, () =>
    Math.floor(Math.random() * 16).toString(16),
  ).join("");
  return `sk_${hex}`;
}


// ---------------------------------------------------------------------------
// Head/tail truncation for large workflow text
// ---------------------------------------------------------------------------

/** Keep first 35% and last 65% — ensures completion message is never truncated */
export function headTailTruncate(text: string, maxChars: number): string {
  if (text.length <= maxChars) return text;
  const headChars = Math.floor(maxChars * 0.35);
  const tailChars = maxChars - headChars - 30;
  return text.slice(0, headChars) + "\n...[中间内容已截断]...\n" + text.slice(-tailChars);
}
