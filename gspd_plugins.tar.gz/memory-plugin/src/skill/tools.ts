/**
 * Skill management tools: skill_list, skill_get, skill_event_list
 *
 * Registered as OpenClaw tools so the agent (and user) can query
 * skill metadata and lifecycle events directly.
 */

import { Type } from "@sinclair/typebox";
import type { OpenClawPluginApi } from "openclaw/plugin-sdk";
import type { GspdMcpClient } from "../core/client.js";

// ============================================================================
// Tool registration
// ============================================================================

export function registerSkillTools(
  api: OpenClawPluginApi,
  client: GspdMcpClient,
): void {
  // ------------------------------------------------------------------
  // skill_list
  // ------------------------------------------------------------------

  api.registerTool(
    {
      name: "skill_list",
      label: "Skill List",
      description:
        "List all learned skills with optional sorting and limit.",
      parameters: Type.Object({
        sortBy: Type.Optional(
          Type.String({
            description:
              "Sort field: created_at (default), updated_at, inject_count, name",
          }),
        ),
        limit: Type.Optional(
          Type.Number({ description: "Max results (default 50, max 500)" }),
        ),
      }),
      async execute(_toolCallId, params) {
        const { sortBy, limit } = params as {
          sortBy?: string;
          limit?: number;
        };

        const raw = (await client.callTool("skill_list", {
          ...(sortBy ? { sortBy } : {}),
          ...(limit != null ? { limit } : {}),
        })) as {
          workflow_count: number;
          experience_count: number;
          workflows: Array<Record<string, unknown>>;
          experiences: Array<Record<string, unknown>>;
        };

        const wf = raw.workflows ?? [];
        const exp = raw.experiences ?? [];

        if (wf.length === 0 && exp.length === 0) {
          return {
            content: [{ type: "text", text: "No skills found." }],
            details: { workflow_count: 0, experience_count: 0 },
          };
        }

        const parts: string[] = [];

        if (wf.length > 0) {
          const lines = wf.map(
            (s, i) =>
              `${i + 1}. [${s.id}] **${s.name}** (v${s.version}, ${s.status}) — injected ${s.inject_count}x`,
          );
          parts.push(`### Workflows (${wf.length})\n\n${lines.join("\n")}`);
        }

        if (exp.length > 0) {
          const lines = exp.map(
            (s, i) =>
              `${i + 1}. [${s.id}] **${s.name}** (v${s.version}) — ${s.description}`,
          );
          parts.push(`### Experience (${exp.length})\n\n${lines.join("\n")}`);
        }

        return {
          content: [{ type: "text", text: parts.join("\n\n") }],
          details: raw,
        };
      },
    },
  );

  // ------------------------------------------------------------------
  // skill_get
  // ------------------------------------------------------------------

  api.registerTool(
    {
      name: "skill_get",
      label: "Skill Detail",
      description:
        "Get detailed information about a single skill by ID, name, or slug. " +
        "Returns all metadata fields and the SKILL.md content.",
      parameters: Type.Object({
        skillId: Type.Optional(
          Type.String({ description: "Skill ID (sk_<8hex>)" }),
        ),
        name: Type.Optional(
          Type.String({ description: "Skill name" }),
        ),
        slug: Type.Optional(
          Type.String({ description: "Skill slug" }),
        ),
      }),
      async execute(_toolCallId, params) {
        const { skillId, name, slug } = params as {
          skillId?: string;
          name?: string;
          slug?: string;
        };

        if (!skillId && !name && !slug) {
          return {
            content: [
              { type: "text", text: "Provide skillId, name, or slug." },
            ],
            details: { error: "missing_param" },
          };
        }

        const raw = (await client.callTool("skill_get", {
          ...(skillId ? { skillId } : {}),
          ...(name ? { name } : {}),
          ...(slug ? { slug } : {}),
        })) as Record<string, unknown>;

        const kind = (raw.kind as string) ?? "workflow";
        const header =
          `**${raw.name}** (${raw.id}, ${kind})\n` +
          `Status: ${raw.status} | Version: ${raw.version}\n` +
          `Injected: ${raw.inject_count}x | Success: ${raw.success_count} | Fail: ${raw.fail_count}`;

        let body = "";
        if (kind === "experience") {
          body =
            `\n\nContext: ${raw.context ?? "(none)"}` +
            `\nDescription: ${raw.description ?? "(none)"}`;
        } else if (raw.content) {
          body = `\n\n---\n\n${raw.content}`;
        }

        return {
          content: [{ type: "text", text: header + body }],
          details: raw,
        };
      },
    },
  );

  // ------------------------------------------------------------------
  // skill_event_list
  // ------------------------------------------------------------------

  api.registerTool(
    {
      name: "skill_event_list",
      label: "Skill Events",
      description:
        "List lifecycle events for skills. Filter by skill ID/name/slug, " +
        "event type, or time range.",
      parameters: Type.Object({
        skillId: Type.Optional(
          Type.String({ description: "Filter by skill ID" }),
        ),
        name: Type.Optional(
          Type.String({ description: "Filter by skill name" }),
        ),
        slug: Type.Optional(
          Type.String({ description: "Filter by skill slug" }),
        ),
        eventType: Type.Optional(
          Type.String({
            description:
              "Filter by event type: CREATED, INJECTED, MERGED, EVOLVED, etc.",
          }),
        ),
        limit: Type.Optional(
          Type.Number({ description: "Max results (default 50, max 500)" }),
        ),
        since: Type.Optional(
          Type.Number({ description: "Start timestamp (epoch seconds)" }),
        ),
      }),
      async execute(_toolCallId, params) {
        const { skillId, name, slug, eventType, limit, since } = params as {
          skillId?: string;
          name?: string;
          slug?: string;
          eventType?: string;
          limit?: number;
          since?: number;
        };

        const raw = (await client.callTool("skill_event_list", {
          ...(skillId ? { skillId } : {}),
          ...(name ? { name } : {}),
          ...(slug ? { slug } : {}),
          ...(eventType ? { eventType } : {}),
          ...(limit != null ? { limit } : {}),
          ...(since != null ? { since } : {}),
        })) as { count: number; events: Array<Record<string, unknown>> };

        if (!raw.events || raw.events.length === 0) {
          return {
            content: [{ type: "text", text: "No events found." }],
            details: { count: 0 },
          };
        }

        const lines = raw.events.map((e) => {
          const ts = new Date(
            (e.created_at as number) * 1000,
          ).toISOString();
          return `- [${ts}] **${e.event_type}** (skill: ${e.skill_id})${e.detail ? ` — ${String(e.detail).slice(0, 80)}` : ""}`;
        });

        return {
          content: [
            {
              type: "text",
              text: `${raw.count} event(s):\n\n${lines.join("\n")}`,
            },
          ],
          details: raw,
        };
      },
    },
  );
}
