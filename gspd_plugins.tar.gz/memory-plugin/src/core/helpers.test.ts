/**
 * Standalone test for helpers — formatContextSection tier labels & drill hints.
 *
 * Run with: npx tsx gspd_memo/openclaw-plugin/src/helpers.test.ts
 */

import assert from "node:assert/strict";
import { formatContextSection } from "./helpers.js";
import type { McpSearchRecord } from "./client.js";

let passed = 0;
let failed = 0;

function test(name: string, fn: () => void): void {
  try {
    fn();
    passed++;
    console.log(`  PASS  ${name}`);
  } catch (e) {
    failed++;
    console.error(`  FAIL  ${name}`);
    console.error(`        ${(e as Error).message}`);
  }
}

console.log("\n=== helpers tests ===\n");

// ─── L2 records: no tier label, no drill hint ───

test("L2 record (tier=2) has no tier label or drill hint", () => {
  const records: McpSearchRecord[] = [
    { id: 1, score: 0.85, confidence: 0.9, createdAtMs: 0, content: "detail memory", tier: 2 },
  ];
  const out = formatContextSection(records);
  assert.ok(!out.includes("[L0 theme]"), "should not contain L0 label");
  assert.ok(!out.includes("[L1 topic]"), "should not contain L1 label");
  assert.ok(!out.includes("memory_drill"), "should not contain drill hint");
  assert.ok(out.includes("[score=85%]"), "should contain score");
  assert.ok(out.includes("detail memory"), "should contain content");
});

test("undefined tier has no tier label or drill hint", () => {
  const records: McpSearchRecord[] = [
    { id: 2, score: 0.7, confidence: 0.8, createdAtMs: 0, content: "plain memory" },
  ];
  const out = formatContextSection(records);
  assert.ok(!out.includes("[L0 theme]"));
  assert.ok(!out.includes("[L1 topic]"));
  assert.ok(!out.includes("memory_drill"));
});

// ─── L0 records: theme label + drill hint ───

test("L0 record has [L0 theme] label and drill hint with parentId", () => {
  const records: McpSearchRecord[] = [
    { id: 42, score: 0.95, confidence: 1.0, createdAtMs: 0, content: "programming preferences", tier: 0 },
  ];
  const out = formatContextSection(records);
  assert.ok(out.includes("[L0 theme]"), "should contain L0 label");
  assert.ok(out.includes("memory_drill"), "should contain drill hint");
  assert.ok(out.includes("parentId=42"), "should contain correct parentId");
});

// ─── L1 records: topic label + drill hint ───

test("L1 record has [L1 topic] label and drill hint with parentId", () => {
  const records: McpSearchRecord[] = [
    { id: 99, score: 0.8, confidence: 0.9, createdAtMs: 0, content: "TypeScript preferences", tier: 1 },
  ];
  const out = formatContextSection(records);
  assert.ok(out.includes("[L1 topic]"), "should contain L1 label");
  assert.ok(out.includes("memory_drill"), "should contain drill hint");
  assert.ok(out.includes("parentId=99"), "should contain correct parentId");
});

// ─── Mixed tier results ───

test("mixed L0 + L2 results: only L0 has drill hint", () => {
  const records: McpSearchRecord[] = [
    { id: 10, score: 0.9, confidence: 1.0, createdAtMs: 0, content: "theme summary", tier: 0 },
    { id: 11, score: 0.7, confidence: 0.8, createdAtMs: 0, content: "leaf detail", tier: 2 },
  ];
  const out = formatContextSection(records);
  const lines = out.split("\n");
  // line 0 is header, line 1 is L0, line 2 is L2
  assert.ok(lines[1].includes("[L0 theme]"), "L0 line has label");
  assert.ok(lines[1].includes("parentId=10"), "L0 line has drill hint");
  assert.ok(!lines[2].includes("[L0 theme]"), "L2 line has no L0 label");
  assert.ok(!lines[2].includes("memory_drill"), "L2 line has no drill hint");
});

// ─── Empty results ───

test("empty records returns header only", () => {
  const out = formatContextSection([]);
  assert.equal(out, "### Relevant Context");
});

// ─── Summary ───

console.log(`\n  ${passed} passed, ${failed} failed\n`);
if (failed > 0) process.exit(1);
