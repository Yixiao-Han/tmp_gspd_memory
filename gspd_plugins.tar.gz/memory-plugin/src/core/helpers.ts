/**
 * 共享辅助函数：转义、格式化、用户 ID 解析。
 */

import type { McpSearchRecord } from "./client.js";

// ============================================================================
// Prompt escape for memory injection
// ============================================================================

const PROMPT_ESCAPE_MAP: Record<string, string> = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;",
};

export function escapeMemoryForPrompt(text: string): string {
  return text.replace(/[&<>"']/g, (c) => PROMPT_ESCAPE_MAP[c] ?? c);
}

// ============================================================================
// Format memories for context injection
// ============================================================================

function tierLabel(tier?: number): string {
  if (tier === 0) return "[L0 theme]";
  if (tier === 1) return "[L1 topic]";
  return "";
}

export function formatContextSection(records: McpSearchRecord[]): string {
  const lines = records.map((r) => {
    const text = r.content ?? "(no content)";
    const score = Math.round(r.score * 100);
    const label = tierLabel(r.tier);
    const drillHint =
      (r.tier === 0 || r.tier === 1) && r.id
        ? ` (use memory_drill with parentId=${r.id} for details)`
        : "";
    return `- ${label}[score=${score}%] ${escapeMemoryForPrompt(text)}${drillHint}`;
  });
  return ["### Relevant Context", ...lines].join("\n");
}

// ============================================================================
// Derive per-user userId from openclaw session key
// ============================================================================

export function deriveUserId(
  ctx: { sessionKey?: string } | undefined,
  fallback: string,
): string {
  const sk = ctx?.sessionKey;
  if (sk) {
    const MARKER = "gradio:dm:";
    const idx = sk.indexOf(MARKER);
    if (idx !== -1) return sk.slice(idx + MARKER.length);
  }
  return fallback;
}
