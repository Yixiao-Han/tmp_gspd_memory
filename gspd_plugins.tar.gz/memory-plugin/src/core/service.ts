/**
 * 背景服务实现：MCP server 生命周期管理 + 内部 HTTP 路由。
 *
 * 暴露两个内部 HTTP 路由，供 chat.py 在 OpenClaw 模式下调用，
 * 避免 chat.py 自己 spawn gspd_mcp_server 与 gateway 竞争同一 DB 文件：
 *
 *   POST /gspd/memory_add   { userId, content, scope }  → memory_add MCP 工具
 *   POST /gspd/clear_user   {}                           → 停进程 + 删 DB + 重启
 */

import { existsSync, unlinkSync } from "node:fs";
import type { IncomingMessage, ServerResponse } from "node:http";
import type { OpenClawPluginApi } from "openclaw/plugin-sdk";
import type { GspdMcpClient } from "./client.js";
import type { GspdMemoryConfig } from "./config.js";


async function readBody(req: IncomingMessage): Promise<string> {
  return new Promise((resolve, reject) => {
    let data = "";
    req.on("data", (chunk: Buffer) => { data += chunk.toString(); });
    req.on("end", () => resolve(data));
    req.on("error", reject);
  });
}

export function registerService(
  api: OpenClawPluginApi,
  client: GspdMcpClient,
  cfg: GspdMemoryConfig,
  resolvedDbPath: string,
): void {
  api.registerService({
    id: "gspd",
    start: async () => {
      await client.start();
      api.logger.info(
        `gspd: server started (binary: ${cfg.serverBinaryPath}, db: ${resolvedDbPath})`,
      );
    },
    stop: () => {
      client.close();
      api.logger.info("gspd: server stopped");
    },
  });

  // ── POST /gspd/memory_add ──────────────────────────────────────────────────
  // Internal route: chat.py calls this to add a memory record without spawning
  // its own gspd_mcp_server process.
  api.registerHttpRoute({
    path: "/gspd/memory_add",
    auth: "plugin",
    handler: async (req: IncomingMessage, res: ServerResponse) => {
      let result: unknown;
      try {
        const body = await readBody(req);
        const { userId, content, scope } = JSON.parse(body) as {
          userId: string;
          content: string;
          scope: string;
        };
        result = await client.callTool("memory_add", { userId, content, scope });
        res.statusCode = 200;
      } catch (e) {
        result = { error: String(e) };
        res.statusCode = 500;
      }
      res.setHeader("Content-Type", "application/json");
      res.end(JSON.stringify(result));
      return true;
    },
  });

  // ── POST /gspd/clear_user ──────────────────────────────────────────────────
  // Internal route: stop gspd_mcp_server, delete DB file, restart.
  // Used by chat.py clear_memories in openclaw mode.
  api.registerHttpRoute({
    path: "/gspd/clear_user",
    auth: "plugin",
    handler: async (_req: IncomingMessage, res: ServerResponse) => {
      try {
        client.close();
        for (const suffix of ["", "-wal", "-shm"]) {
          const p = resolvedDbPath + suffix;
          if (existsSync(p)) unlinkSync(p);
        }
        await client.start();
        res.statusCode = 200;
        res.setHeader("Content-Type", "application/json");
        res.end(JSON.stringify({ ok: true }));
      } catch (e) {
        res.statusCode = 500;
        res.setHeader("Content-Type", "application/json");
        res.end(JSON.stringify({ error: String(e) }));
      }
      return true;
    },
  });
}
