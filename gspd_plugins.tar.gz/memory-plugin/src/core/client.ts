/**
 * GsPD MCP Client — stdio JSON-RPC 2.0 通信层。
 */

import { spawn, type ChildProcess } from "node:child_process";

// ============================================================================
// MCP search result types
// ============================================================================

export type McpSearchRecord = {
  id: number;
  score: number;
  confidence: number;
  createdAtMs: number;
  content?: string;
  tier?: number;
  parentId?: number;
};

export type McpSearchResponse = {
  count: number;
  status: number;
  results: McpSearchRecord[];
};

export function parseSearchResponse(raw: unknown): McpSearchResponse {
  if (raw && typeof raw === "object" && "results" in raw) {
    return raw as McpSearchResponse;
  }
  return { count: 0, status: 0, results: [] };
}

/** Alias — memory_drill returns the same shape as memory_search. */
export const parseDrillResponse = parseSearchResponse;

// ============================================================================
// MCP list result types
// ============================================================================

export type McpListRecord = {
  id: number;
  category: number;
  confidence: number;
  createdAtMs: number;
  userId?: string;
  agentId?: string;
  text?: string;
};

export type McpListResponse = {
  count: number;
  status: number;
  offset: number;
  records: McpListRecord[];
};

export function parseListResponse(raw: unknown): McpListResponse {
  if (raw && typeof raw === "object" && "records" in raw) {
    return raw as McpListResponse;
  }
  return { count: 0, status: 0, offset: 0, records: [] };
}

// ============================================================================
// GsPD MCP Client (stdio JSON-RPC 2.0)
// ============================================================================

export class GspdMcpClient {
  private proc: ChildProcess | null = null;
  private nextId = 1;
  private pending = new Map<
    number,
    { resolve: (v: unknown) => void; reject: (e: Error) => void }
  >();
  private buffer = "";

  /** Set to false by close() to suppress auto-restart on intentional shutdown. */
  private shouldRestart = false;
  /** Exponential backoff state for restart attempts. */
  private restartAttempts = 0;
  /**
   * Monotonically increasing generation counter.  Each spawn() call gets its
   * own generation ID so that a stale `exit` event from a previously-killed
   * process (which may arrive asynchronously AFTER a new process has already
   * been started) is silently discarded rather than nullifying the new process
   * reference or triggering an unwanted restart.
   */
  private procGeneration = 0;

  constructor(
    private readonly binaryPath: string,
    private readonly dbPath: string,
    private env: Record<string, string>,
  ) {}

  /**
   * Merge additional env vars from a later caller (e.g. memory-plugin
   * registering after context-engine-plugin). New keys are added;
   * existing keys are NOT overwritten to respect the first caller.
   */
  mergeEnv(extra: Record<string, string>): void {
    for (const [k, v] of Object.entries(extra)) {
      if (!(k in this.env)) {
        this.env[k] = v;
      }
    }
  }

  async start(): Promise<void> {
    if (this.isConnected()) return;  // already running
    this.shouldRestart = true;
    this.restartAttempts = 0;
    await this.spawn();
  }

  private async spawn(): Promise<void> {
    const generation = ++this.procGeneration;

    this.proc = spawn(this.binaryPath, [this.dbPath], {
      stdio: ["pipe", "pipe", "pipe"],
      env: { ...process.env, ...this.env },
    });

    this.proc.stdout!.on("data", (chunk: Buffer) => this.onData(chunk));
    this.proc.stderr!.on("data", (chunk: Buffer) => {
      process.stderr.write(`[gspd-mcp] ${chunk}`);
    });
    this.proc.on("exit", (code) => {
      // Discard stale exit events from previously-killed processes.
      // This prevents a delayed exit from an old process from nullifying the
      // new process reference or triggering an unwanted restart loop.
      if (generation !== this.procGeneration) return;

      for (const { reject } of this.pending.values()) {
        reject(new Error(`gspd_mcp_server exited with code ${code}`));
      }
      this.pending.clear();
      this.proc = null;

      if (this.shouldRestart) {
        // Exponential backoff: 1s, 2s, 4s, 8s, max 30s
        const delayMs = Math.min(1000 * Math.pow(2, this.restartAttempts), 30_000);
        this.restartAttempts++;
        process.stderr.write(`[gspd-mcp] process exited (code ${code}), restarting in ${delayMs}ms (attempt ${this.restartAttempts})\n`);
        setTimeout(() => {
          if (this.shouldRestart) {
            this.spawn().catch((err) => {
              process.stderr.write(`[gspd-mcp] restart failed: ${err}\n`);
            });
          }
        }, delayMs);
      }
    });

    await this.request("initialize", {
      protocolVersion: "2025-03-26",
      capabilities: {},
      clientInfo: { name: "openclaw-memory-gspd", version: "0.1.0" },
    });
    this.send({ jsonrpc: "2.0", method: "notifications/initialized" });
    // Successful start resets backoff
    this.restartAttempts = 0;
  }

  async callTool(
    name: string,
    args: Record<string, unknown>,
    timeoutMs = 120_000,
  ): Promise<unknown> {
    // Lazy-start: auto-connect on first tool call if not already running
    if (!this.isConnected()) {
      await this.start();
    }

    const result = (await this.request("tools/call", {
      name,
      arguments: args,
    }, timeoutMs)) as { content?: Array<{ text?: string }>; isError?: boolean };

    if (result.isError) {
      const text = result.content?.[0]?.text ?? "Unknown MCP tool error";
      throw new Error(text);
    }

    const text = result.content?.[0]?.text;
    if (text) {
      try {
        let parsed = JSON.parse(text);
        // C server sometimes double-encodes JSON (string wrapping an object).
        // Unwrap one extra layer if needed.
        if (typeof parsed === "string") {
          try { parsed = JSON.parse(parsed); } catch { /* keep as string */ }
        }
        return parsed;
      } catch {
        return text;
      }
    }
    return result;
  }

  close(): void {
    this.shouldRestart = false;
    if (this.proc) {
      this.proc.kill();
      this.proc = null;
    }
  }

  isConnected(): boolean {
    return this.proc !== null && this.proc.exitCode === null;
  }

  /** Wait until the server is connected, with timeout. */
  async waitReady(timeoutMs = 5000): Promise<boolean> {
    if (this.isConnected()) return true;
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      await new Promise((r) => setTimeout(r, 200));
      if (this.isConnected()) return true;
    }
    return false;
  }

  private request(method: string, params: unknown, timeoutMs = 120_000): Promise<unknown> {
    return new Promise((resolve, reject) => {
      const id = this.nextId++;
      this.pending.set(id, { resolve, reject });
      this.send({ jsonrpc: "2.0", id, method, params });

      setTimeout(() => {
        if (this.pending.has(id)) {
          this.pending.delete(id);
          reject(new Error(`MCP request timeout: ${method}`));
        }
      }, timeoutMs);
    });
  }

  private send(msg: object): void {
    if (!this.proc?.stdin?.writable) {
      throw new Error("gspd_mcp_server is not running");
    }
    this.proc.stdin.write(JSON.stringify(msg) + "\n");
  }

  private onData(chunk: Buffer): void {
    this.buffer += chunk.toString();
    const lines = this.buffer.split("\n");
    this.buffer = lines.pop() ?? "";

    for (const line of lines) {
      if (!line.trim()) continue;
      try {
        const msg = JSON.parse(line) as {
          id?: number;
          result?: unknown;
          error?: { code: number; message: string };
        };
        if (msg.id != null && this.pending.has(msg.id)) {
          const { resolve, reject } = this.pending.get(msg.id)!;
          this.pending.delete(msg.id);
          if (msg.error) {
            reject(new Error(`MCP error ${msg.error.code}: ${msg.error.message}`));
          } else {
            resolve(msg.result);
          }
        }
      } catch {
        // Ignore unparseable lines
      }
    }
  }
}
