import { homedir } from "node:os";
import { join } from "node:path";

export type GspdMemoryConfig = {
  serverBinaryPath: string;
  dbPath: string;
  userId: string;
  vectorDim?: number;
  embed: { baseUrl: string; apiKey: string; model: string };
  chat: { baseUrl: string; apiKey: string; model: string };
  autoRecall: boolean;
  autoCapture: boolean;

  // inteSkill
  skillsDir: string;
  autoLearn: boolean;
  autoInject: boolean;
  enableMerge: boolean;
  enableEvents: boolean;
  topK: number;
  topKExperience: number;
  minScore: number;
  maxChars: number;
  dedupThreshold: number;
  tailTurns: number;
  debug: boolean;
};

const DEFAULT_DB_PATH = join(homedir(), ".openclaw", "memory", "gspd_memory.db");
const DEFAULT_SKILLS_DIR = join(homedir(), ".openclaw", "memory", "skills");
const DEFAULT_EMBED_MODEL = "text-embedding-3-small";
const DEFAULT_CHAT_MODEL = "gpt-4o-mini";

function resolveEnvVars(value: string): string {
  return value.replace(/\$\{([^}]+)\}/g, (_, envVar) => {
    let envValue = process.env[envVar];
    // Windows fallbacks for common Unix env vars
    if (!envValue && process.platform === "win32") {
      if (envVar === "HOME") envValue = process.env.USERPROFILE;
      else if (envVar === "USER") envValue = process.env.USERNAME;
    }
    if (!envValue) {
      throw new Error(`Environment variable ${envVar} is not set`);
    }
    return envValue;
  });
}

function assertAllowedKeys(
  value: Record<string, unknown>,
  allowed: string[],
  label: string,
) {
  const unknown = Object.keys(value).filter((key) => !allowed.includes(key));
  if (unknown.length > 0) {
    throw new Error(`${label} has unknown keys: ${unknown.join(", ")}`);
  }
}

export const gspdMemoryConfigSchema = {
  parse(value: unknown): GspdMemoryConfig {
    if (!value || typeof value !== "object" || Array.isArray(value)) {
      throw new Error("memory-gspd config required");
    }
    const cfg = value as Record<string, unknown>;
    assertAllowedKeys(
      cfg,
      [
        "serverBinaryPath",
        "dbPath",
        "userId",
        "vectorDim",
        "embed",
        "chat",
        "autoRecall",
        "autoCapture",
        // inteSkill
        "skillsDir",
        "autoLearn",
        "autoInject",
        "enableMerge",
        "enableEvents",
        "topK",
        "topKExperience",
        "minScore",
        "maxChars",
        "dedupThreshold",
        "tailTurns",
        "debug",
      ],
      "memory-gspd config",
    );

    if (typeof cfg.serverBinaryPath !== "string" || !cfg.serverBinaryPath) {
      throw new Error("serverBinaryPath is required");
    }

    const embed = cfg.embed as Record<string, unknown> | undefined;
    if (!embed || typeof embed.apiKey !== "string" || typeof embed.baseUrl !== "string") {
      throw new Error("embed.baseUrl and embed.apiKey are required");
    }
    assertAllowedKeys(embed, ["baseUrl", "apiKey", "model"], "embed config");

    const chat = cfg.chat as Record<string, unknown> | undefined;
    if (!chat || typeof chat.apiKey !== "string" || typeof chat.baseUrl !== "string") {
      throw new Error("chat.baseUrl and chat.apiKey are required");
    }
    assertAllowedKeys(chat, ["baseUrl", "apiKey", "model"], "chat config");

    return {
      serverBinaryPath: cfg.serverBinaryPath,
      dbPath: typeof cfg.dbPath === "string" ? cfg.dbPath : DEFAULT_DB_PATH,
      userId: typeof cfg.userId === "string" ? cfg.userId : "openclaw-user",
      vectorDim: typeof cfg.vectorDim === "number" ? cfg.vectorDim : undefined,
      embed: {
        baseUrl: resolveEnvVars(embed.baseUrl),
        apiKey: resolveEnvVars(embed.apiKey),
        model:
          typeof embed.model === "string" ? embed.model : DEFAULT_EMBED_MODEL,
      },
      chat: {
        baseUrl: resolveEnvVars(chat.baseUrl),
        apiKey: resolveEnvVars(chat.apiKey),
        model:
          typeof chat.model === "string" ? chat.model : DEFAULT_CHAT_MODEL,
      },
      autoRecall: cfg.autoRecall !== false,
      autoCapture: cfg.autoCapture !== false,

      // inteSkill
      skillsDir: typeof cfg.skillsDir === "string" ? cfg.skillsDir : DEFAULT_SKILLS_DIR,
      autoLearn: cfg.autoLearn === true,
      autoInject: cfg.autoInject === true,
      enableMerge: cfg.enableMerge !== false,      // default true
      enableEvents: cfg.enableEvents !== false,     // default true
      topK: typeof cfg.topK === "number" ? cfg.topK : 3,
      topKExperience: typeof cfg.topKExperience === "number" ? cfg.topKExperience : 5,
      minScore: typeof cfg.minScore === "number" ? cfg.minScore : 0.75,
      maxChars: typeof cfg.maxChars === "number" ? cfg.maxChars : 1500,
      dedupThreshold: typeof cfg.dedupThreshold === "number" ? cfg.dedupThreshold : 0.78,
      tailTurns: typeof cfg.tailTurns === "number" ? cfg.tailTurns : 5,
      debug: cfg.debug === true,           // default false
    };
  },
};
