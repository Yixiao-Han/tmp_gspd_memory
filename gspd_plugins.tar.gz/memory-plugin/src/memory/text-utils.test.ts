/**
 * Standalone test for text-utils capture decision logic.
 *
 * Run with: npx tsx gspd_memo/openclaw-plugin/src/text-utils.test.ts
 *           (or: node --loader ts-node/esm ...)
 */

import assert from "node:assert/strict";
import {
  sanitizeUserTextForCapture,
  getCaptureDecision,
  resolveCaptureMinLength,
  extractTextsFromUserMessages,
  extractLatestUserText,
  pickRecentUniqueTexts,
  CAPTURE_LIMIT,
  CAPTURE_MAX_CHARS,
} from "./text-utils.js";

let passed = 0;
let failed = 0;

function test(name: string, fn: () => void): void {
  try {
    fn();
    passed++;
    console.log(`  PASS  ${name}`);
  } catch (e) {
    failed++;
    console.error(`  FAIL  ${name}`);
    console.error(`        ${(e as Error).message}`);
  }
}

console.log("\n=== text-utils tests ===\n");

// ─── CJK-aware min length ───

test("resolveCaptureMinLength: CJK text returns 4", () => {
  assert.equal(resolveCaptureMinLength("我喜欢咖啡"), 4);
});

test("resolveCaptureMinLength: English text returns 10", () => {
  assert.equal(resolveCaptureMinLength("hello world"), 10);
});

// ─── Fix 1: Question suffix detection ───

test("question: Chinese interrogative '我喜欢什么' → llm_candidate (not regex)", () => {
  const d = getCaptureDecision("我喜欢什么");
  assert.equal(d.shouldCapture, false);
  assert.equal(d.reason, "llm_candidate");
});

test("question: '我喜欢吃什么？' → llm_candidate", () => {
  const d = getCaptureDecision("我喜欢吃什么？");
  assert.equal(d.shouldCapture, false);
  assert.equal(d.reason, "llm_candidate");
});

test("question: '我的名字是什么' → llm_candidate", () => {
  const d = getCaptureDecision("我的名字是什么");
  assert.equal(d.shouldCapture, false);
  assert.equal(d.reason, "llm_candidate");
});

test("question: '你记住了哪些' → llm_candidate", () => {
  const d = getCaptureDecision("你记住了哪些");
  assert.equal(d.shouldCapture, false);
  assert.equal(d.reason, "llm_candidate");
});

test("question: '我偏好什么颜色呢' → llm_candidate", () => {
  const d = getCaptureDecision("我偏好什么颜色呢");
  assert.equal(d.shouldCapture, false);
  assert.equal(d.reason, "llm_candidate");
});

test("question: '你记得吗' → llm_candidate", () => {
  const d = getCaptureDecision("你记得吗");
  assert.equal(d.shouldCapture, false);
  assert.equal(d.reason, "llm_candidate");
});

test("question: trailing '?' → llm_candidate", () => {
  const d = getCaptureDecision("Do you remember my name?");
  assert.equal(d.shouldCapture, false);
  assert.equal(d.reason, "llm_candidate");
});

test("question: '怎么做蛋糕' → llm_candidate", () => {
  const d = getCaptureDecision("怎么做蛋糕");
  assert.equal(d.shouldCapture, false);
  assert.equal(d.reason, "llm_candidate");
});

test("question: '为什么天是蓝色的' → llm_candidate", () => {
  const d = getCaptureDecision("为什么天是蓝色的");
  assert.equal(d.shouldCapture, false);
});

test("question: '哪里有好吃的' → llm_candidate", () => {
  const d = getCaptureDecision("哪里有好吃的");
  assert.equal(d.shouldCapture, false);
});

// ─── Statements should still capture via regex ───

test("statement: '我喜欢吃牛排' → regex capture", () => {
  const d = getCaptureDecision("我喜欢吃牛排");
  assert.equal(d.shouldCapture, true);
  assert.equal(d.reason, "regex");
});

test("statement: '记住我的名字叫华少' → regex capture", () => {
  const d = getCaptureDecision("记住我的名字叫华少");
  assert.equal(d.shouldCapture, true);
  assert.equal(d.reason, "regex");
});

test("statement: '我讨厌吃辣' → regex capture", () => {
  const d = getCaptureDecision("我讨厌吃辣");
  assert.equal(d.shouldCapture, true);
  assert.equal(d.reason, "regex");
});

test("statement: 'I prefer dark mode' → regex capture", () => {
  const d = getCaptureDecision("I prefer dark mode");
  assert.equal(d.shouldCapture, true);
  assert.equal(d.reason, "regex");
});

test("statement: 'remember my birthday is March 5' → regex capture", () => {
  const d = getCaptureDecision("remember my birthday is March 5");
  assert.equal(d.shouldCapture, true);
  assert.equal(d.reason, "regex");
});

test("statement: '我的邮箱是test@example.com' → regex capture", () => {
  const d = getCaptureDecision("我的邮箱是test@example.com");
  assert.equal(d.shouldCapture, true);
  assert.equal(d.reason, "regex");
});

// ─── Edge cases ───

test("empty string → empty reason", () => {
  const d = getCaptureDecision("");
  assert.equal(d.shouldCapture, false);
  assert.equal(d.reason, "empty");
});

test("short CJK (< 4 chars) → too_short", () => {
  const d = getCaptureDecision("你好");
  assert.equal(d.shouldCapture, false);
  assert.match(d.reason, /too_short/);
});

test("slash command → command", () => {
  const d = getCaptureDecision("/memory list");
  assert.equal(d.shouldCapture, false);
  assert.equal(d.reason, "command");
});

test("punctuation only → non_content", () => {
  const d = getCaptureDecision("!!!???...!!!");
  assert.equal(d.shouldCapture, false);
  assert.equal(d.reason, "non_content");
});

test("too long → too_long", () => {
  const long = "a".repeat(CAPTURE_MAX_CHARS + 1);
  const d = getCaptureDecision(long);
  assert.equal(d.shouldCapture, false);
  assert.equal(d.reason, "too_long");
});

test("injection residue → injection_residue", () => {
  const d = getCaptureDecision("some text <relevant-memories>injected</relevant-memories> more");
  assert.equal(d.shouldCapture, false);
  assert.equal(d.reason, "injection_residue");
});

// ─── Sanitization ───

test("sanitize: strips <relevant-memories> block", () => {
  const raw = "hello <relevant-memories>secret</relevant-memories> world";
  const result = sanitizeUserTextForCapture(raw);
  assert.equal(result, "hello  world");
});

test("sanitize: strips message_id prefix", () => {
  const raw = "[message_id: om_abc123] actual message";
  const result = sanitizeUserTextForCapture(raw);
  assert.equal(result, "actual message");
});

// ─── No regex match → llm_candidate ───

test("neutral statement → llm_candidate (no regex match)", () => {
  const d = getCaptureDecision("今天天气真不错啊");
  assert.equal(d.shouldCapture, false);
  assert.equal(d.reason, "llm_candidate");
});

// ─── Message extraction helpers ───

test("extractTextsFromUserMessages: filters user role only", () => {
  const msgs = [
    { role: "user", content: "hello" },
    { role: "assistant", content: "hi" },
    { role: "user", content: "world" },
  ];
  const texts = extractTextsFromUserMessages(msgs);
  assert.deepEqual(texts, ["hello", "world"]);
});

test("extractLatestUserText: returns last user message sanitized", () => {
  const msgs = [
    { role: "user", content: "first" },
    { role: "assistant", content: "reply" },
    { role: "user", content: "  second  " },
  ];
  const text = extractLatestUserText(msgs);
  assert.equal(text, "second");
});

test("pickRecentUniqueTexts: deduplicates case-insensitive", () => {
  const texts = ["Hello", "world", "HELLO", "World"];
  const result = pickRecentUniqueTexts(texts, 3);
  assert.equal(result.length, 2);
});

// ─── Summary ───

console.log(`\n${passed} passed, ${failed} failed\n`);
if (failed > 0) process.exit(1);
