/**
 * 工具注册：memory_recall / memory_store / memory_forget + CLI 命令。
 */

import { Type } from "@sinclair/typebox";
import type { OpenClawPluginApi } from "openclaw/plugin-sdk";
import type { GspdMcpClient } from "../core/client.js";
import { parseSearchResponse, parseListResponse } from "../core/client.js";
import type { GspdMemoryConfig } from "../core/config.js";
import { deriveUserId } from "../core/helpers.js";

// ============================================================================
// Tool registration
// ============================================================================

export function registerTools(
  api: OpenClawPluginApi,
  client: GspdMcpClient,
  cfg: GspdMemoryConfig,
): void {
  // ------------------------------------------------------------------
  // Inject per-session userId into memory tool params before execution
  // ------------------------------------------------------------------

  const MEMORY_TOOLS = new Set([
    "memory_recall", "memory_store", "memory_forget", "memory_list",
    "memory_drill",
  ]);

  api.on("before_tool_call", (event, ctx) => {
    if (!MEMORY_TOOLS.has(event.toolName)) return;
    const userId = deriveUserId(ctx, cfg.userId);
    return { params: { ...event.params, _userId: userId } };
  });

  // ------------------------------------------------------------------
  // memory_recall
  // ------------------------------------------------------------------

  api.registerTool(
    {
      name: "memory_recall",
      label: "Memory Recall",
      description:
        "Search through long-term memories. Use when you need context about user preferences, past decisions, or previously discussed topics.",
      parameters: Type.Object({
        query: Type.String({ description: "Search query" }),
        limit: Type.Optional(
          Type.Number({ description: "Max results (default: 5)" }),
        ),
      }),
      async execute(_toolCallId, params) {
        const { query, limit = 5, _userId } = params as {
          query: string;
          limit?: number;
          _userId?: string;
        };
        const userId = _userId ?? cfg.userId;

        api.logger.info(`[memory_recall] query="${query}" topK=${limit} userId=${userId}`);

        const raw = await client.callTool("memory_search", {
          query,
          topK: limit,
          userId,
        });

        const data = parseSearchResponse(raw);
        if (data.results.length === 0) {
          api.logger.info(`[memory_recall] → no results`);
          return {
            content: [
              { type: "text", text: "No relevant memories found." },
            ],
            details: { count: 0 },
          };
        }

        const text = data.results
          .map((r, i) => {
            const content = r.content ?? "(empty)";
            return `${i + 1}. ${content} (${Math.round(r.score * 100)}%)`;
          })
          .join("\n");

        api.logger.info(`[memory_recall] → ${data.results.length} results:\n${text}`);

        return {
          content: [
            {
              type: "text",
              text: `Found ${data.results.length} memories:\n\n${text}`,
            },
          ],
          details: {
            count: data.results.length,
            memories: data.results.map((r) => ({
              id: r.id,
              score: r.score,
              content: r.content,
              confidence: r.confidence,
            })),
          },
        };
      },
    },
  );

  // ------------------------------------------------------------------
  // memory_store
  // ------------------------------------------------------------------

  api.registerTool(
    {
      name: "memory_store",
      label: "Memory Store",
      description:
        "Save important information in long-term memory. Use for preferences, facts, decisions. The engine handles conflict detection and deduplication automatically.",
      parameters: Type.Object({
        text: Type.String({ description: "Information to remember" }),
      }),
      async execute(_toolCallId, params) {
        const { text, _userId } = params as { text: string; _userId?: string };
        const userId = _userId ?? cfg.userId;

        api.logger.info(`[memory_store] text="${text.slice(0, 120)}" userId=${userId}`);

        const raw = (await client.callTool("memory_add", {
          content: text,
          userId,
          scope: "user",
        })) as { id?: number; status?: number };

        api.logger.info(`[memory_store] → id=${raw.id} status=${raw.status}`);

        return {
          content: [
            {
              type: "text",
              text: `Stored: "${text.slice(0, 100)}${text.length > 100 ? "..." : ""}"`,
            },
          ],
          details: { action: "created", id: raw.id, status: raw.status },
        };
      },
    },
  );

  // ------------------------------------------------------------------
  // memory_forget
  // ------------------------------------------------------------------

  api.registerTool(
    {
      name: "memory_forget",
      label: "Memory Forget",
      description: "Delete specific memories by ID or search query.",
      parameters: Type.Object({
        query: Type.Optional(
          Type.String({ description: "Search to find memory to delete" }),
        ),
        memoryId: Type.Optional(
          Type.Number({ description: "Specific memory ID to delete" }),
        ),
      }),
      async execute(_toolCallId, params) {
        const { query, memoryId, _userId } = params as {
          query?: string;
          memoryId?: number;
          _userId?: string;
        };
        const userId = _userId ?? cfg.userId;

        if (memoryId != null) {
          await client.callTool("memory_delete", { memoryId });
          return {
            content: [
              { type: "text", text: `Memory ${memoryId} forgotten.` },
            ],
            details: { action: "deleted", id: memoryId },
          };
        }

        if (query) {
          const raw = await client.callTool("memory_search", {
            query,
            topK: 5,
            userId,
          });
          const data = parseSearchResponse(raw);

          if (data.results.length === 0) {
            return {
              content: [
                { type: "text", text: "No matching memories found." },
              ],
              details: { found: 0 },
            };
          }

          if (data.results.length === 1 && data.results[0].score > 0.9) {
            const target = data.results[0];
            await client.callTool("memory_delete", {
              memoryId: target.id,
            });
            const desc = target.content ?? "(memory)";
            return {
              content: [
                { type: "text", text: `Forgotten: "${desc}"` },
              ],
              details: { action: "deleted", id: target.id },
            };
          }

          const list = data.results
            .map(
              (r) =>
                `- [id:${r.id}] ${(r.content ?? "").slice(0, 60)}...`,
            )
            .join("\n");

          return {
            content: [
              {
                type: "text",
                text: `Found ${data.results.length} candidates. Specify memoryId:\n${list}`,
              },
            ],
            details: {
              action: "candidates",
              candidates: data.results.map((r) => ({
                id: r.id,
                score: r.score,
                content: r.content,
              })),
            },
          };
        }

        return {
          content: [
            { type: "text", text: "Provide query or memoryId." },
          ],
          details: { error: "missing_param" },
        };
      },
    },
  );

  // ------------------------------------------------------------------
  // memory_list
  // ------------------------------------------------------------------

  api.registerTool(
    {
      name: "memory_list",
      label: "Memory List",
      description:
        "List all stored memories with pagination.",
      parameters: Type.Object({
        limit: Type.Optional(
          Type.Number({ description: "Max records (default: 20, max: 100)" }),
        ),
        offset: Type.Optional(
          Type.Number({ description: "Pagination offset (default: 0)" }),
        ),
      }),
      async execute(_toolCallId, params) {
        const {
          limit = 20,
          offset = 0,
          _userId,
        } = params as {
          limit?: number;
          offset?: number;
          _userId?: string;
        };
        const userId = _userId ?? cfg.userId;

        const raw = await client.callTool("memory_list", {
          limit,
          offset,
          userId,
        });

        const data = parseListResponse(raw);
        if (data.records.length === 0) {
          return {
            content: [
              { type: "text", text: "No memories found." },
            ],
            details: { count: 0, offset },
          };
        }

        const text = data.records
          .map((r, i) => {
            const content = r.text ?? "(empty)";
            return `${offset + i + 1}. [id:${r.id}] ${content}`;
          })
          .join("\n");

        return {
          content: [
            {
              type: "text",
              text: `${data.count} memories (offset=${offset}):\n\n${text}`,
            },
          ],
          details: {
            count: data.count,
            offset,
            records: data.records,
          },
        };
      },
    },
  );

  // ------------------------------------------------------------------
  // memory_drill
  // ------------------------------------------------------------------

  api.registerTool(
    {
      name: "memory_drill",
      label: "Memory Drill",
      description:
        "Drill into a summary memory (L0 theme / L1 topic) to load its child records with detail. " +
        "Use when memory_recall returns a summary you want to expand.",
      parameters: Type.Object({
        parentId: Type.Number({
          description: "ID of the parent memory to drill into",
        }),
        query: Type.Optional(
          Type.String({
            description: "Original query for score propagation",
          }),
        ),
        topK: Type.Optional(
          Type.Number({ description: "Max children to return (default: 5)" }),
        ),
      }),
      async execute(_toolCallId, params) {
        const { parentId, query, topK = 5, _userId } = params as {
          parentId: number;
          query?: string;
          topK?: number;
          _userId?: string;
        };
        const userId = _userId ?? cfg.userId;

        api.logger.info(
          `[memory_drill] parentId=${parentId} query="${query ?? ""}" topK=${topK} userId=${userId}`,
        );

        const raw = await client.callTool("memory_drill", {
          parentId,
          query: query ?? "",
          topK,
          userId,
        });

        const data = parseSearchResponse(raw);
        if (data.results.length === 0) {
          return {
            content: [
              { type: "text", text: "No child memories found for this parent." },
            ],
            details: { count: 0 },
          };
        }

        const text = data.results
          .map((r, i) => {
            const content = r.content ?? "(empty)";
            return `${i + 1}. ${content} (${Math.round(r.score * 100)}%)`;
          })
          .join("\n");

        api.logger.info(
          `[memory_drill] → ${data.results.length} children:\n${text}`,
        );

        return {
          content: [
            {
              type: "text",
              text: `${data.results.length} detail memories:\n\n${text}`,
            },
          ],
          details: {
            count: data.results.length,
            memories: data.results.map((r) => ({
              id: r.id,
              score: r.score,
              content: r.content,
              tier: r.tier,
            })),
          },
        };
      },
    },
  );

  // ------------------------------------------------------------------
  // skill_list
  // ------------------------------------------------------------------

  api.registerTool(
    {
      name: "skill_list",
      label: "Skill List",
      description:
        "List all learned skills with optional sorting and limit.",
      parameters: Type.Object({
        sortBy: Type.Optional(
          Type.String({
            description:
              "Sort field: created_at (default), updated_at, inject_count, name",
          }),
        ),
        limit: Type.Optional(
          Type.Number({ description: "Max results (default 50, max 500)" }),
        ),
      }),
      async execute(_toolCallId, params) {
        const { sortBy, limit } = params as {
          sortBy?: string;
          limit?: number;
        };

        const raw = (await client.callTool("skill_list", {
          ...(sortBy ? { sortBy } : {}),
          ...(limit != null ? { limit } : {}),
        })) as {
          workflow_count: number;
          experience_count: number;
          workflows: Array<Record<string, unknown>>;
          experiences: Array<Record<string, unknown>>;
        };

        const wf = raw.workflows ?? [];
        const exp = raw.experiences ?? [];

        if (wf.length === 0 && exp.length === 0) {
          return {
            content: [{ type: "text", text: "No skills found." }],
            details: { workflow_count: 0, experience_count: 0 },
          };
        }

        const parts: string[] = [];

        if (wf.length > 0) {
          const lines = wf.map(
            (s, i) =>
              `${i + 1}. [${s.id}] **${s.name}** (v${s.version}, ${s.status}) — injected ${s.inject_count}x`,
          );
          parts.push(`### Workflows (${wf.length})\n\n${lines.join("\n")}`);
        }

        if (exp.length > 0) {
          const lines = exp.map(
            (s, i) =>
              `${i + 1}. [${s.id}] **${s.name}** (v${s.version}) — ${s.description}`,
          );
          parts.push(`### Experience (${exp.length})\n\n${lines.join("\n")}`);
        }

        return {
          content: [{ type: "text", text: parts.join("\n\n") }],
          details: raw,
        };
      },
    },
  );

  // ------------------------------------------------------------------
  // skill_get
  // ------------------------------------------------------------------

  api.registerTool(
    {
      name: "skill_get",
      label: "Skill Detail",
      description:
        "Get detailed information about a single skill by ID, name, or slug. " +
        "Returns all metadata fields and the SKILL.md content.",
      parameters: Type.Object({
        skillId: Type.Optional(
          Type.String({ description: "Skill ID (sk_<8hex>)" }),
        ),
        name: Type.Optional(
          Type.String({ description: "Skill name" }),
        ),
        slug: Type.Optional(
          Type.String({ description: "Skill slug" }),
        ),
      }),
      async execute(_toolCallId, params) {
        const { skillId, name, slug } = params as {
          skillId?: string;
          name?: string;
          slug?: string;
        };

        if (!skillId && !name && !slug) {
          return {
            content: [
              { type: "text", text: "Provide skillId, name, or slug." },
            ],
            details: { error: "missing_param" },
          };
        }

        const raw = (await client.callTool("skill_get", {
          ...(skillId ? { skillId } : {}),
          ...(name ? { name } : {}),
          ...(slug ? { slug } : {}),
        })) as Record<string, unknown>;

        const header =
          `**${raw.name}** (${raw.id})\n` +
          `Status: ${raw.status} | Version: ${raw.version}\n` +
          `Injected: ${raw.inject_count}x | Success: ${raw.success_count} | Fail: ${raw.fail_count}`;

        const content = raw.content
          ? `\n\n---\n\n${raw.content}`
          : "";

        return {
          content: [{ type: "text", text: header + content }],
          details: raw,
        };
      },
    },
  );

  // ------------------------------------------------------------------
  // skill_event_list
  // ------------------------------------------------------------------

  api.registerTool(
    {
      name: "skill_event_list",
      label: "Skill Events",
      description:
        "List lifecycle events for skills. Filter by skill ID/name/slug, " +
        "event type, or time range.",
      parameters: Type.Object({
        skillId: Type.Optional(
          Type.String({ description: "Filter by skill ID" }),
        ),
        name: Type.Optional(
          Type.String({ description: "Filter by skill name" }),
        ),
        slug: Type.Optional(
          Type.String({ description: "Filter by skill slug" }),
        ),
        eventType: Type.Optional(
          Type.String({
            description:
              "Filter by event type: CREATED, INJECTED, MERGED, EVOLVED, etc.",
          }),
        ),
        limit: Type.Optional(
          Type.Number({ description: "Max results (default 50, max 500)" }),
        ),
        since: Type.Optional(
          Type.Number({ description: "Start timestamp (epoch seconds)" }),
        ),
      }),
      async execute(_toolCallId, params) {
        const { skillId, name, slug, eventType, limit, since } = params as {
          skillId?: string;
          name?: string;
          slug?: string;
          eventType?: string;
          limit?: number;
          since?: number;
        };

        const raw = (await client.callTool("skill_event_list", {
          ...(skillId ? { skillId } : {}),
          ...(name ? { name } : {}),
          ...(slug ? { slug } : {}),
          ...(eventType ? { eventType } : {}),
          ...(limit != null ? { limit } : {}),
          ...(since != null ? { since } : {}),
        })) as { count: number; events: Array<Record<string, unknown>> };

        if (!raw.events || raw.events.length === 0) {
          return {
            content: [{ type: "text", text: "No events found." }],
            details: { count: 0 },
          };
        }

        const lines = raw.events.map((e) => {
          const ts = new Date(
            (e.created_at as number) * 1000,
          ).toISOString();
          return `- [${ts}] **${e.event_type}** (skill: ${e.skill_id})${e.detail ? ` — ${String(e.detail).slice(0, 80)}` : ""}`;
        });

        return {
          content: [
            {
              type: "text",
              text: `${raw.count} event(s):\n\n${lines.join("\n")}`,
            },
          ],
          details: raw,
        };
      },
    },
  );
}

// ============================================================================
// CLI commands
// ============================================================================

export function registerCli(
  api: OpenClawPluginApi,
  client: GspdMcpClient,
  cfg: GspdMemoryConfig,
): void {
  api.registerCli(
    ({ program }) => {
      const mem = program
        .command("gspd-mem")
        .description("GsPD memory plugin commands");

      mem
        .command("search")
        .description("Search memories")
        .argument("<query>", "Search query")
        .option("--limit <n>", "Max results", "5")
        .action(async (query: string, opts: { limit: string }) => {
          const raw = await client.callTool("memory_search", {
            query,
            topK: parseInt(opts.limit),
            userId: cfg.userId,
          });
          const data = parseSearchResponse(raw);
          const output = data.results.map((r) => ({
            id: r.id,
            score: r.score,
            confidence: r.confidence,
            content: r.content,
          }));
          console.log(JSON.stringify(output, null, 2));
        });

      mem
        .command("store")
        .description("Store a memory")
        .argument("<text>", "Text to store")
        .action(async (text: string) => {
          const raw = await client.callTool("memory_add", {
            content: text,
            userId: cfg.userId,
            scope: "user",
          });
          console.log(JSON.stringify(raw, null, 2));
        });

      mem
        .command("list")
        .description("List stored memories")
        .option("--limit <n>", "Max records", "20")
        .option("--offset <n>", "Pagination offset", "0")
        .option("--user <userId>", "Filter by user ID")
        .action(
          async (opts: {
            limit: string;
            offset: string;
            user?: string;
          }) => {
            const raw = await client.callTool("memory_list", {
              limit: parseInt(opts.limit),
              offset: parseInt(opts.offset),
              userId: opts.user ?? cfg.userId,
            });
            const data = parseListResponse(raw);

            if (data.records.length === 0) {
              console.log("No memories found.");
              return;
            }

            console.log(
              `${data.count} memories (offset=${data.offset}):`,
            );
            console.log("");
            for (const [i, r] of data.records.entries()) {
              const idx = data.offset + i + 1;
              const content = r.text ?? "(empty)";
              console.log(`  ${idx}. [id:${r.id}] ${content}`);
            }
          },
        );
    },
    { commands: ["gspd-mem"] },
  );
}
