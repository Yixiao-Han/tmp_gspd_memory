export {
  registerAutoRecall,
  registerAutoCapture,
  registerWorkspaceHooks,
} from "./hooks.js";
export { registerTools, registerCli } from "./tools.js";
export {
  sanitizeUserTextForCapture,
  getCaptureDecision,
  extractTextsFromUserMessages,
  extractLatestUserText,
  pickRecentUniqueTexts,
  resolveCaptureMinLength,
  CAPTURE_LIMIT,
  CAPTURE_MAX_CHARS,
} from "./text-utils.js";
export type { CaptureDecision } from "./text-utils.js";
