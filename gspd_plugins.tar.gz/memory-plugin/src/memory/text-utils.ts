/**
 * Text sanitization utilities for GsPD memory auto-capture.
 *
 * "Strip-down" approach: iteratively remove known metadata envelopes
 * from platform-wrapped user messages, leaving only the original user text.
 *
 * Inspired by OpenViking memory plugin text-utils.
 */

// ============================================================================
// Regex constants — known metadata patterns injected by the platform
// ============================================================================

/** Injected <relevant-memories>…</relevant-memories> blocks from recall */
const RELEVANT_MEMORIES_BLOCK_RE =
  /<relevant-memories>[\s\S]*?<\/relevant-memories>/gi;

/**
 * OpenViking-style profile/memory context injected by chat.py into user messages.
 * Marker phrase: "以下核心用户信息已固定加载在上下文中" (always present in profile header).
 * These blocks must not be re-captured as new memories.
 */
const OV_PROFILE_CONTEXT_RE =
  /##\s*\S[^\n]*\n以下核心用户信息已固定加载在上下文中[\s\S]*/i;

/** "Conversation info (untrusted metadata): ```json … ```" envelope */
const CONVERSATION_METADATA_BLOCK_RE =
  /(?:^|\n)\s*(?:Conversation info|Conversation metadata|会话信息|对话信息)\s*(?:\([^)]+\))?\s*:\s*```[\s\S]*?```/gi;

/** "Sender (untrusted metadata): ```json … ```" envelope */
const SENDER_METADATA_BLOCK_RE = /Sender\s*\([^)]*\)\s*:\s*```[\s\S]*?```/gi;

/** Fenced JSON blocks with ≥3 known metadata keys → probably platform envelope */
const FENCED_JSON_BLOCK_RE = /```json\s*([\s\S]*?)```/gi;
const METADATA_JSON_KEY_RE =
  /"(session|sessionid|sessionkey|conversationid|channel|sender|userid|agentid|timestamp|timezone|message_id|sender_id)"\s*:/gi;

/** "[message_id: om_xxx]" line prefix */
const LEADING_MESSAGE_ID_RE = /\[message_id:\s*[^\]]+\]\s*/g;

/** "ou_84b090637e001185dcc1421f4e723cd7: " speaker prefix (multiline: each line) */
const SPEAKER_PREFIX_RE = /^[a-z0-9_]{10,}:\s*/gim;

/** Slash-command text like /memory, /help */
const COMMAND_TEXT_RE = /^\/[a-z0-9_-]{1,64}\b/i;

/** Text that is only punctuation / symbols / whitespace — no real content */
const NON_CONTENT_TEXT_RE = /^[\p{P}\p{S}\s]+$/u;

/** CJK character range (Chinese, Japanese, Korean) */
const CJK_CHAR_REGEX =
  /[\u3040-\u30ff\u3400-\u9fff\uf900-\ufaff\uac00-\ud7af]/;

// ============================================================================
// Auto-capture trigger patterns
// ============================================================================

/**
 * Chinese interrogative suffixes — questions are retrieval intents, not memories.
 * Matches: "什么", "哪些", "哪个", "吗", "呢", "?", "？" at end of text.
 */
const QUESTION_SUFFIX_RE =
  /(?:什么|哪些|哪个|怎[么样]|如何|为什么|多少|几个?|谁|哪里|哪儿)[？?]?\s*$|[？?]\s*$|吗[？?。]?\s*$|呢[？?。]?\s*$/;

const MEMORY_TRIGGERS = [
  // English
  /remember|zapamatuj/i,
  /prefer|radši|nechci/i,
  /decided|rozhodli/i,
  /\+\d{10,}/,
  /[\w.-]+@[\w.-]+\.\w+/,
  /my\s+\w+\s+is|is\s+my/i,
  /i (like|prefer|hate|love|want|need)/i,
  /always|never|important/i,
  // Chinese
  /记住|记得|别忘/,
  /我(喜欢|讨厌|偏好|不喜欢|爱|想要|需要|习惯)/,
  /我的(名字|地址|邮箱|手机|电话|生日|工作|职业)/,
  /喜欢用|偏好用|常用|一直用/,
  /决定了|选择了|定了/,
  /重要|务必|一定要|千万/,
  /以后|今后|从现在起/,
];

/** Maximum number of messages to capture per conversation turn */
export const CAPTURE_LIMIT = 3;

/** Maximum character length for a single capture */
export const CAPTURE_MAX_CHARS = 500;

// ============================================================================
// Core sanitization
// ============================================================================

/**
 * Strip platform metadata envelopes from a raw user message.
 *
 * Works by iteratively removing known metadata patterns (relevant-memories
 * blocks, conversation/sender metadata envelopes, fenced JSON with metadata
 * keys, message-id line prefixes, speaker prefixes) and returning whatever
 * remains — the actual user text.
 */
export function sanitizeUserTextForCapture(raw: string): string {
  let text = raw;

  // 1. Remove null characters
  text = text.replace(/\0/g, "");

  // 2. Remove <relevant-memories> injection blocks
  text = text.replace(RELEVANT_MEMORIES_BLOCK_RE, "");

  // 2b. Remove OpenViking-style profile context blocks injected by chat.py
  text = text.replace(OV_PROFILE_CONTEXT_RE, "");

  // 3. Remove "Conversation info …: ```json … ```" envelope
  text = text.replace(CONVERSATION_METADATA_BLOCK_RE, "");

  // 4. Remove "Sender (…): ```json … ```" envelope
  text = text.replace(SENDER_METADATA_BLOCK_RE, "");

  // 5. Remove fenced JSON blocks that contain ≥3 metadata keys
  text = text.replace(FENCED_JSON_BLOCK_RE, (match, jsonBody: string) => {
    const keyMatches = jsonBody.match(METADATA_JSON_KEY_RE);
    return keyMatches && keyMatches.length >= 3 ? "" : match;
  });

  // 6. Remove [message_id: …] line prefixes
  text = text.replace(LEADING_MESSAGE_ID_RE, "");

  // 7. Remove speaker id prefix (e.g. "ou_84b090637e001185: ")
  text = text.replace(SPEAKER_PREFIX_RE, "");

  // 8. Normalize whitespace
  text = text.replace(/\n{3,}/g, "\n\n").trim();

  return text;
}

// ============================================================================
// Capture decision
// ============================================================================

/** Resolve the minimum capture length based on CJK presence */
export function resolveCaptureMinLength(text: string): number {
  return CJK_CHAR_REGEX.test(text) ? 4 : 10;
}

export type CaptureDecision = {
  shouldCapture: boolean;
  reason: string;
  normalizedText: string;
};

/**
 * Structured capture decision for a single sanitized text.
 *
 * Checks (in order):
 *  1. Length too short (CJK-aware) → skip
 *  2. Length too long → skip
 *  3. Starts with / (command) → skip
 *  4. Only punctuation/symbols → skip
 *  5. Contains <relevant-memories> (injection residue) → skip
 *  6. Regex trigger match → capture ("regex")
 *  7. Otherwise → candidate for LLM fallback ("llm_candidate")
 */
export function getCaptureDecision(
  text: string,
  captureMaxLength = CAPTURE_MAX_CHARS,
): CaptureDecision {
  const normalized = text.trim();

  if (!normalized) {
    return { shouldCapture: false, reason: "empty", normalizedText: "" };
  }

  const minLen = resolveCaptureMinLength(normalized);
  if (normalized.length < minLen) {
    return {
      shouldCapture: false,
      reason: `too_short (${normalized.length} < ${minLen})`,
      normalizedText: normalized,
    };
  }

  if (normalized.length > captureMaxLength) {
    return {
      shouldCapture: false,
      reason: "too_long",
      normalizedText: normalized,
    };
  }

  if (COMMAND_TEXT_RE.test(normalized)) {
    return {
      shouldCapture: false,
      reason: "command",
      normalizedText: normalized,
    };
  }

  if (NON_CONTENT_TEXT_RE.test(normalized)) {
    return {
      shouldCapture: false,
      reason: "non_content",
      normalizedText: normalized,
    };
  }

  if (normalized.includes("<relevant-memories>")) {
    return {
      shouldCapture: false,
      reason: "injection_residue",
      normalizedText: normalized,
    };
  }

  // Interrogative check: questions match triggers (e.g. "我喜欢什么") but are
  // retrieval intents, not factual memories — route to LLM for final judgment.
  if (QUESTION_SUFFIX_RE.test(normalized)) {
    return {
      shouldCapture: false,
      reason: "llm_candidate",
      normalizedText: normalized,
    };
  }

  // Regex trigger fast-path
  const triggered = MEMORY_TRIGGERS.some((r) => r.test(normalized));
  if (triggered) {
    return {
      shouldCapture: true,
      reason: "regex",
      normalizedText: normalized,
    };
  }

  // No regex match — mark as LLM candidate (caller decides whether to LLM-check)
  return {
    shouldCapture: false,
    reason: "llm_candidate",
    normalizedText: normalized,
  };
}

// ============================================================================
// Message extraction helpers
// ============================================================================

type MessageLike = Record<string, unknown>;

/** Extract raw text content from a single message object. */
function extractTextFromMessage(msg: MessageLike): string | null {
  const content = msg.content;
  if (typeof content === "string") return content;

  if (Array.isArray(content)) {
    for (const block of content) {
      if (
        block &&
        typeof block === "object" &&
        "type" in block &&
        (block as Record<string, unknown>).type === "text" &&
        "text" in block &&
        typeof (block as Record<string, unknown>).text === "string"
      ) {
        return (block as Record<string, unknown>).text as string;
      }
    }
  }
  return null;
}

/**
 * Extract all user-role text content from event.messages.
 * Returns raw (un-sanitized) texts in message order.
 */
export function extractTextsFromUserMessages(
  messages: unknown[] | undefined,
): string[] {
  if (!messages) return [];
  const texts: string[] = [];
  for (const msg of messages) {
    if (!msg || typeof msg !== "object") continue;
    const m = msg as MessageLike;
    if (m.role !== "user") continue;
    const t = extractTextFromMessage(m);
    if (t) texts.push(t);
  }
  return texts;
}

/**
 * Extract the latest user message text (sanitized) for use as a recall query.
 */
export function extractLatestUserText(
  messages: unknown[] | undefined,
): string {
  if (!messages || messages.length === 0) return "";
  for (let i = messages.length - 1; i >= 0; i--) {
    const msg = messages[i];
    if (!msg || typeof msg !== "object") continue;
    const m = msg as MessageLike;
    if (m.role !== "user") continue;
    const t = extractTextFromMessage(m);
    if (t) return sanitizeUserTextForCapture(t);
  }
  return "";
}

/**
 * From the tail of a text array, pick up to `limit` unique entries.
 * Deduplication is case-insensitive.
 */
export function pickRecentUniqueTexts(
  texts: string[],
  limit: number,
): string[] {
  const seen = new Set<string>();
  const result: string[] = [];
  for (let i = texts.length - 1; i >= 0 && result.length < limit; i--) {
    const key = texts[i].toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    result.push(texts[i]);
  }
  return result.reverse();
}
