/**
 * OpenClaw GsPD Plugin — Memory + inteSkill
 *
 * Provides:
 * - 3-tier semantic memory with conflict detection
 * - inteSkill: intelligent skill lifecycle (Learn → Index → Inject → Dedup → Evolve)
 *
 * Backed by C/SQLite engine via MCP (gspd_mcp_server).
 */

import type { OpenClawPluginApi } from "openclaw/plugin-sdk";
import { getOrCreateGspdClient } from "../shared/gspd-client-singleton.js";
import { gspdMemoryConfigSchema } from "./src/core/config.js";
import { registerService } from "./src/core/service.js";
import {
  registerAutoRecall,
  registerAutoCapture,
} from "./src/memory/hooks.js";
import { registerTools, registerCli } from "./src/memory/tools.js";
import { registerSkillInject, registerSkillLearn } from "./src/skill/hooks.js";

// ============================================================================
// Plugin Definition
// ============================================================================

const gspdPlugin = {
  id: "memory-gspd",
  name: "GsPD (Memory + inteSkill)",
  description:
    "3-tier semantic memory + intelligent skill lifecycle, backed by C/SQLite engine via MCP",
  kind: "memory" as const,
  configSchema: gspdMemoryConfigSchema,

  register(api: OpenClawPluginApi) {
    const cfg = gspdMemoryConfigSchema.parse(api.pluginConfig);
    const resolvedDbPath = api.resolvePath(cfg.dbPath);

    const clientEnv: Record<string, string> = {
      OPENAI_EMBED_BASE_URL: cfg.embed.baseUrl,
      OPENAI_EMBED_API_KEY: cfg.embed.apiKey,
      OPENAI_EMBED_MODEL: cfg.embed.model,
      OPENAI_CHAT_BASE_URL: cfg.chat.baseUrl,
      OPENAI_CHAT_API_KEY: cfg.chat.apiKey,
      OPENAI_CHAT_MODEL: cfg.chat.model,
    };

    if (cfg.skillsDir) {
      clientEnv.GSPD_SKILLS_DIR = cfg.skillsDir;
    }

    if (cfg.vectorDim) {
      clientEnv.GSPD_VECTOR_DIM = String(cfg.vectorDim);
    }
    if (process.env.GSPD_VECTOR_DIM) {
      clientEnv.GSPD_VECTOR_DIM = process.env.GSPD_VECTOR_DIM;
    } else if (process.env.EMBED_DIM) {
      clientEnv.GSPD_VECTOR_DIM = process.env.EMBED_DIM;
    }

    // Log level: debug when cfg.debug is true, otherwise info
    clientEnv.GSPD_LOG_LEVEL = cfg.debug ? "debug" : "info";
    // Let C server pick the default log path (%TEMP%/gspd_memo.log on Windows)
    // Only override if explicitly set in env
    if (process.env.GSPD_LOG_FILE) {
      clientEnv.GSPD_LOG_FILE = process.env.GSPD_LOG_FILE;
    }

    if (cfg.debug) {
      clientEnv.GSPD_DEBUG = "1";
    }

    const client = getOrCreateGspdClient(cfg.serverBinaryPath, resolvedDbPath, clientEnv);

    api.logger.info(
      `gspd: registered (binary: ${cfg.serverBinaryPath}, db: ${resolvedDbPath}, ` +
      `skillsDir: ${cfg.skillsDir}, inject=${cfg.autoInject}, learn=${cfg.autoLearn})`,
    );

    registerTools(api, client, cfg);
    registerCli(api, client, cfg);

    if (cfg.autoRecall) registerAutoRecall(api, client, cfg);
    if (cfg.autoCapture) registerAutoCapture(api, client, cfg);

    if (cfg.autoInject) registerSkillInject(api, client, cfg);
    if (cfg.autoLearn) registerSkillLearn(api, client, cfg);

    registerService(api, client, cfg, resolvedDbPath);
  },
};

export default gspdPlugin;
