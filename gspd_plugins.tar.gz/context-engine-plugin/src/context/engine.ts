import type { AgentMessage } from "@mariozechner/pi-agent-core";
import type {
  OpenClawPluginApi,
  ContextEngine,
  AssembleResult,
  CompactResult,
  IngestResult,
  IngestBatchResult,
  BootstrapResult,
  SubagentSpawnPreparation,
  SubagentEndReason,
} from "openclaw/plugin-sdk";
import { getSharedActiveSessionsMap } from "../../../shared/gspd-client-singleton.js";
import type { GspdMcpClient } from "../../../shared/gspd-client-singleton.js";
import type { GspdContextConfig, GspdContextSkillConfig } from "../core/config.js";

export interface ContextEngineConfig {
  tokenBudget: number;
  safetyMarginPct?: number;
  recentTurnsToKeep?: number;
  autoCompact?: boolean;
  skill?: GspdContextSkillConfig;
}

function toRoleString(role: unknown): string {
  if (typeof role === "string") {
    const r = role.toLowerCase();
    if (r === "assistant" || r === "ai") return "assistant";
    if (r === "system") return "system";
    if (r === "tool" || r === "function") return "tool";
  }
  return "user";
}

function extractContent(msg: unknown): string {
  if (!msg || typeof msg !== "object") return "";
  const m = msg as Record<string, unknown>;
  if (typeof m.content === "string") return m.content;
  if (Array.isArray(m.content)) {
    return m.content
      .map((c) => (typeof c === "string" ? c : (c as Record<string, unknown>)?.text ?? ""))
      .filter(Boolean)
      .join("\n");
  }
  return "";
}

/** Strip previously-injected skill prompt that may leak into user messages. */
function stripSkillInjection(text: string): string {
  return text
    .replace(/\*\*重要 — 必须使用技能\*\*[\s\S]*?不需要注明。\s*/g, "")
    .replace(/\*\*重要 — 必须使用技能\*\*[\s\S]*$/g, "")
    .trim();
}

function extractLastUserQuery(messages: AgentMessage[]): string {
  for (let i = messages.length - 1; i >= 0; i--) {
    const m = messages[i] as unknown as Record<string, unknown>;
    if (m.role !== "user") continue;
    const text = stripSkillInjection(extractContent(messages[i]));
    if (text && text.length >= 5) return text;
  }
  return "";
}

export function createGsPDContextEngine(
  api: OpenClawPluginApi,
  client: GspdMcpClient,
  _cfg: GspdContextConfig,
  engineCfg: ContextEngineConfig,
): ContextEngine {
  // Shared across re-registrations: OpenClaw calls register() per agent turn,
  // so we persist activeSessions in globalThis to avoid context_init resets.
  const activeSessions = getSharedActiveSessionsMap();

  async function simpleHash(str: string): Promise<string> {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return hash.toString(16);
  }

  async function ensureSession(sessionId: string): Promise<boolean> {
    if (activeSessions.has(sessionId)) return true;

    if (!client.isConnected() && !(await client.waitReady())) {
      api.logger.warn?.("context-gspd: server not ready");
      return false;
    }

    api.logger.info?.(`context-gspd: ensureSession calling context_init for ${sessionId}`);
    try {
      const result = (await client.callTool("context_init", {
        sessionId,
        tenantId: "default",
        tokenBudget: engineCfg.tokenBudget,
        safetyMarginPct: engineCfg.safetyMarginPct ?? 5,
        recentTurnsToKeep: engineCfg.recentTurnsToKeep ?? 10,
      })) as { status?: number };

      if (result.status === 0) {
        activeSessions.set(sessionId, { fragmentIds: [], turnIds: [], registeredSystemHashes: new Set() });
        api.logger.info?.(`context-gspd: context_init success for ${sessionId}`);
        return true;
      }
      api.logger.warn?.(`context-gspd: context_init failed with status ${result.status}`);
      return false;
    } catch (err) {
      api.logger.warn?.(`context-gspd: context_init error: ${String(err)}`);
      return false;
    }
  }

  return {
    info: {
      id: "context-gspd",
      name: "GsPD Context Engine",
      version: "1.0.0",
      ownsCompaction: true,
    },

    async ingest({ sessionId, message, isHeartbeat }: {
      sessionId: string;
      sessionKey?: string;
      message: AgentMessage;
      isHeartbeat?: boolean;
    }): Promise<IngestResult> {
      if (isHeartbeat) return { ingested: false };
      api.logger.info?.(`context-gspd: ingest called for ${sessionId}`);

      if (!(await ensureSession(sessionId))) {
        return { ingested: false };
      }

      const content = extractContent(message);
      if (!content || content.length < 3) {
        return { ingested: false };
      }

      const role = toRoleString((message as unknown as Record<string, unknown>)?.role);

      try {
        api.logger.info?.(`context-gspd: append_turn sessionId=${sessionId} role=${role} contentLen=${content.length}`);
        const result = (await client.callTool("context_append_turn", {
          sessionId,
          role,
          content,
        })) as { status?: number; turnId?: number };
        api.logger.info?.(`context-gspd: append_turn result status=${result.status} turnId=${result.turnId ?? 0}`);

        if (result.status === 0 && result.turnId) {
          const session = activeSessions.get(sessionId);
          if (session) {
            session.turnIds.push(result.turnId);
          }
          return { ingested: true };
        }
        return { ingested: false };
      } catch (err) {
        api.logger.warn?.(`context-gspd: ingest error: ${String(err)}`);
        return { ingested: false };
      }
    },

    async assemble({
      sessionId,
      messages,
      tokenBudget,
    }: {
      sessionId: string;
      sessionKey?: string;
      messages: AgentMessage[];
      tokenBudget?: number;
    }): Promise<AssembleResult> {
      api.logger.info?.(`[DEBUG] assemble called for session ${sessionId}, messages=${messages.length}`);
      if (!(await ensureSession(sessionId))) {
        api.logger.warn?.(`[DEBUG] assemble: ensureSession failed for ${sessionId}`);
        return { messages, estimatedTokens: 0 };
      }

      if (tokenBudget && tokenBudget !== engineCfg.tokenBudget) {
        try {
          await client.callTool("context_update_budget", {
            sessionId,
            tokenBudget,
            safetyMarginPct: engineCfg.safetyMarginPct ?? 5,
          });
        } catch {
          // Budget update failure should not block assembly
        }
      }

      for (const msg of messages) {
        const m = msg as unknown as Record<string, unknown>;
        if (m.role !== "system") continue;

        const sysContent = extractContent(msg);
        if (sysContent.length === 0) continue;

        const session = activeSessions.get(sessionId);
        if (!session) continue;

        const contentHash = await simpleHash(sysContent);
        if (session.registeredSystemHashes.has(contentHash)) continue;

        try {
          await client.callTool("context_register_fragment", {
            sessionId,
            type: "system_instruction",
            priority: "critical",
            isPinned: true,
            content: sysContent,
          });
          session.registeredSystemHashes.add(contentHash);
        } catch {
          // Ignore fragment registration errors
        }
      }

      // --- Skill inject via context engine ---
      const skillCfg = engineCfg.skill;
      if (skillCfg?.enabled) {
        const query = extractLastUserQuery(messages);
        if (query && query.length >= 5) {
          try {
            const skillResult = (await client.callTool("skill_search", {
              query,
              topK: skillCfg.topK ?? 3,
              topKExperience: skillCfg.topKExperience ?? 5,
              minScore: skillCfg.minScore ?? 0.40,
              status: "active",
              sessionId,
            })) as { catalog: string; count: number };

            if (skillResult.catalog && skillResult.count > 0) {
              const skillContent =
                `**重要 — 必须使用技能**：以下技能已与当前任务匹配。` +
                `浏览下方描述，如有明确适用的技能，立即使用 Read 工具读取其 SKILL.md 并严格按照步骤执行。` +
                `若多个技能均可能适用，选择最具体的那个，读取并严格执行。` +
                `不得跳过技能中定义的步骤，不得自行发挥。\n` +
                `**使用技能后，在回复末尾注明**：「✅ 已使用技能：<技能名称>」。` +
                `如果没有使用任何技能，不需要注明。\n\n` +
                skillResult.catalog;

              await client.callTool("context_register_fragment", {
                sessionId,
                type: "custom",
                priority: "high",
                isPinned: false,
                content: skillContent,
              });
              api.logger.info?.(`context-gspd: skill inject ${skillResult.count} skill(s) via fragment`);
            }
          } catch (err) {
            api.logger.warn?.(`context-gspd: skill search failed: ${String(err)}`);
          }
        }
      }

      try {
        api.logger.info?.(`context-gspd: assemble sessionId=${sessionId}`);
        const result = (await client.callTool("context_assemble", {
          sessionId,
          forceCompress: false,
          incrementalUpdate: false,
        })) as {
          status?: number;
          assembledText?: string;
          totalTokens?: number;
          wasTruncated?: boolean;
          wasCompressed?: boolean;
        };
        api.logger.info?.(`context-gspd: assemble result tokens=${result.totalTokens ?? 0} textLen=${result.assembledText?.length ?? 0}`);

        if (result.status === 0 && result.assembledText) {
          const systemPromptAddition = result.assembledText;
          return {
            messages,
            estimatedTokens: result.totalTokens ?? Math.floor(systemPromptAddition.length / 4),
            systemPromptAddition,
          };
        }

        return { messages, estimatedTokens: 0 };
      } catch (err) {
        api.logger.warn?.(`context-gspd: assemble error: ${String(err)}`);
        return { messages, estimatedTokens: 0 };
      }
    },

    async compact({ sessionId, force }: {
      sessionId: string;
      sessionKey?: string;
      sessionFile: string;
      tokenBudget?: number;
      force?: boolean;
      currentTokenCount?: number;
      compactionTarget?: "budget" | "threshold";
      customInstructions?: string;
      runtimeContext?: unknown;
    }): Promise<CompactResult> {
      if (!(await ensureSession(sessionId))) {
        return { ok: false, compacted: false };
      }

      try {
        api.logger.info?.(`context-gspd: compact sessionId=${sessionId} force=${force ?? true}`);
        const result = (await client.callTool("context_assemble", {
          sessionId,
          forceCompress: force ?? true,
          incrementalUpdate: false,
        })) as {
          status?: number;
          wasCompressed?: boolean;
        };
        api.logger.info?.(`context-gspd: compact result status=${result.status} compressed=${result.wasCompressed}`);

        return {
          ok: result.status === 0,
          compacted: result.wasCompressed ?? false,
        };
      } catch (err) {
        api.logger.warn?.(`context-gspd: compact error: ${String(err)}`);
        return { ok: false, compacted: false };
      }
    },

    async bootstrap({ sessionId }: {
      sessionId: string;
      sessionKey?: string;
      sessionFile: string;
    }): Promise<BootstrapResult> {
      api.logger.info?.(`context-gspd: bootstrap called for ${sessionId}`);
      const ok = await ensureSession(sessionId);
      return { bootstrapped: ok };
    },

    async ingestBatch({
      sessionId,
      messages,
    }: {
      sessionId: string;
      sessionKey?: string;
      messages: AgentMessage[];
      isHeartbeat?: boolean;
    }): Promise<IngestBatchResult> {
      api.logger.info?.(`context-gspd: ingestBatch called for ${sessionId} msgs=${messages.length}`);
      if (!(await ensureSession(sessionId))) return { ingestedCount: 0 };

      const turns = messages
        .map((m) => ({
          role: toRoleString((m as unknown as Record<string, unknown>)?.role),
          content: extractContent(m),
        }))
        .filter((t) => t.content && t.content.length >= 3);

      if (turns.length === 0) return { ingestedCount: 0 };

      try {
        api.logger.info?.(`context-gspd: append_turns sessionId=${sessionId} count=${turns.length}`);
        const result = (await client.callTool("context_append_turns", {
          sessionId,
          turns,
        })) as { status?: number; count?: number };
        api.logger.info?.(`context-gspd: append_turns result status=${result.status} count=${result.count ?? turns.length}`);

        return { ingestedCount: result.count ?? turns.length };
      } catch (err) {
        api.logger.warn?.(`context-gspd: ingestBatch error: ${String(err)}`);
        return { ingestedCount: 0 };
      }
    },

    async afterTurn({ sessionId, messages, prePromptMessageCount }: {
      sessionId: string;
      sessionKey?: string;
      sessionFile: string;
      messages: AgentMessage[];
      prePromptMessageCount: number;
      autoCompactionSummary?: string;
      isHeartbeat?: boolean;
      tokenBudget?: number;
      runtimeContext?: unknown;
    }): Promise<void> {
      api.logger.info?.(`context-gspd: afterTurn called for ${sessionId} msgs=${messages.length} pre=${prePromptMessageCount}`);
      if (!(await ensureSession(sessionId))) return;

      // Ingest only the new messages from this turn (slice off already-ingested messages).
      const newMessages = messages.slice(prePromptMessageCount);
      const turns = newMessages
        .map((m) => ({
          role: toRoleString((m as Record<string, unknown>)?.role),
          content: extractContent(m),
        }))
        .filter((t) => t.role !== "system" && t.content && t.content.length >= 3);

      if (turns.length > 0) {
        try {
          const result = (await client.callTool("context_append_turns", {
            sessionId,
            turns,
          })) as { status?: number; count?: number };
          api.logger.info?.(`context-gspd: afterTurn ingested ${result.count ?? turns.length} turns for ${sessionId}`);
        } catch (err) {
          api.logger.warn?.(`context-gspd: afterTurn ingest error: ${String(err)}`);
        }
      }

      if (engineCfg.autoCompact) {
        try {
          await client.callTool("context_assemble", {
            sessionId,
            forceCompress: false,
          });
        } catch (err) {
          api.logger.warn?.(`context-gspd: afterTurn compact error: ${String(err)}`);
        }
      }
    },

    async prepareSubagentSpawn(_params: {
      parentSessionKey: string;
      childSessionKey: string;
      ttlMs?: number;
    }): Promise<SubagentSpawnPreparation | undefined> {
      // GsPD sessions are isolated; no cross-session state to prepare.
      return undefined;
    },

    async onSubagentEnded(_params: {
      childSessionKey: string;
      reason: SubagentEndReason;
    }): Promise<void> {
      /* No-op: gspd sessions are isolated, no cleanup needed */
    },

    async dispose(): Promise<void> {
      const sessionIds = Array.from(activeSessions.keys());
      api.logger.info?.(`context-gspd: dispose sessions=${sessionIds.length}`);
      activeSessions.clear();

      for (const sessionId of sessionIds) {
        try {
          api.logger.info?.(`context-gspd: dispose destroying sessionId=${sessionId}`);
          await client.callTool("context_destroy", { sessionId });
        } catch {
          // Ignore cleanup errors
        }
      }
    },
  };
}
