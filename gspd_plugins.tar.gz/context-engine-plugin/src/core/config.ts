import { homedir } from "node:os";
import { join } from "node:path";

export type GspdContextSkillConfig = {
  enabled: boolean;
  topK?: number;      // default 3
  topKExperience?: number;  // default 5
  minScore?: number;  // default 0.40
};

export type GspdContextConfig = {
  serverBinaryPath: string;
  dbPath: string;
  vectorDim?: number;
  embed: { baseUrl: string; apiKey: string; model: string };
  chat: { baseUrl: string; apiKey: string; model: string };
  tokenBudget: number;
  safetyMarginPct: number;
  recentTurnsToKeep: number;
  autoCompact: boolean;
  skill?: GspdContextSkillConfig;
};

const DEFAULT_DB_PATH = join(homedir(), ".openclaw", "memory", "gspd_memory.db");
const DEFAULT_EMBED_MODEL = "text-embedding-3-small";
const DEFAULT_CHAT_MODEL = "gpt-4o-mini";

function resolveEnvVars(value: string): string {
  return value.replace(/\$\{([^}]+)\}/g, (_, envVar) => {
    let envValue = process.env[envVar];
    if (!envValue && process.platform === "win32") {
      if (envVar === "HOME") envValue = process.env.USERPROFILE;
      else if (envVar === "USER") envValue = process.env.USERNAME;
    }
    if (!envValue) {
      throw new Error(`Environment variable ${envVar} is not set`);
    }
    return envValue;
  });
}

function assertAllowedKeys(
  value: Record<string, unknown>,
  allowed: string[],
  label: string,
) {
  const unknown = Object.keys(value).filter((key) => !allowed.includes(key));
  if (unknown.length > 0) {
    throw new Error(`${label} has unknown keys: ${unknown.join(", ")}`);
  }
}

export const gspdContextConfigSchema = {
  parse(value: unknown): GspdContextConfig {
    if (!value || typeof value !== "object" || Array.isArray(value)) {
      throw new Error("context-gspd config required");
    }
    const cfg = value as Record<string, unknown>;
    assertAllowedKeys(
      cfg,
      [
        "serverBinaryPath",
        "dbPath",
        "vectorDim",
        "embed",
        "chat",
        "tokenBudget",
        "safetyMarginPct",
        "recentTurnsToKeep",
        "autoCompact",
        "skill",
      ],
      "context-gspd config",
    );

    if (typeof cfg.serverBinaryPath !== "string" || !cfg.serverBinaryPath) {
      throw new Error("serverBinaryPath is required");
    }

    const embed = cfg.embed as Record<string, unknown> | undefined;
    if (!embed || typeof embed.apiKey !== "string" || typeof embed.baseUrl !== "string") {
      throw new Error("embed.baseUrl and embed.apiKey are required");
    }
    assertAllowedKeys(embed, ["baseUrl", "apiKey", "model"], "embed config");

    const chat = cfg.chat as Record<string, unknown> | undefined;
    if (!chat || typeof chat.apiKey !== "string" || typeof chat.baseUrl !== "string") {
      throw new Error("chat.baseUrl and chat.apiKey are required");
    }
    assertAllowedKeys(chat, ["baseUrl", "apiKey", "model"], "chat config");

    let skill: GspdContextSkillConfig | undefined;
    if (cfg.skill && typeof cfg.skill === "object" && !Array.isArray(cfg.skill)) {
      const s = cfg.skill as Record<string, unknown>;
      assertAllowedKeys(s, ["enabled", "topK", "topKExperience", "minScore"], "skill config");
      skill = {
        enabled: s.enabled === true,
        topK: typeof s.topK === "number" ? s.topK : undefined,
        topKExperience: typeof s.topKExperience === "number" ? s.topKExperience : undefined,
        minScore: typeof s.minScore === "number" ? s.minScore : undefined,
      };
    }

    return {
      serverBinaryPath: cfg.serverBinaryPath,
      dbPath: typeof cfg.dbPath === "string" ? cfg.dbPath : DEFAULT_DB_PATH,
      vectorDim: typeof cfg.vectorDim === "number" ? cfg.vectorDim : undefined,
      embed: {
        baseUrl: resolveEnvVars(embed.baseUrl),
        apiKey: resolveEnvVars(embed.apiKey),
        model: typeof embed.model === "string" ? embed.model : DEFAULT_EMBED_MODEL,
      },
      chat: {
        baseUrl: resolveEnvVars(chat.baseUrl),
        apiKey: resolveEnvVars(chat.apiKey),
        model: typeof chat.model === "string" ? chat.model : DEFAULT_CHAT_MODEL,
      },
      tokenBudget: typeof cfg.tokenBudget === "number" ? cfg.tokenBudget : 128000,
      safetyMarginPct: typeof cfg.safetyMarginPct === "number" ? cfg.safetyMarginPct : 5,
      recentTurnsToKeep: typeof cfg.recentTurnsToKeep === "number" ? cfg.recentTurnsToKeep : 10,
      autoCompact: cfg.autoCompact !== false,
      skill,
    };
  },
};
