/**
 * OpenClaw GsPD Context Engine Plugin
 *
 * Token budget management, compression, and context assembly,
 * backed by C/SQLite engine via MCP.
 *
 * Shares a single gspd_mcp_server process with memory-plugin
 * via a global singleton client.
 */

import type { OpenClawPluginApi } from "openclaw/plugin-sdk";
import { getOrCreateGspdClient, setSkillInjectViaContext } from "../shared/gspd-client-singleton.js";
import { gspdContextConfigSchema } from "./src/core/config.js";
import { createGsPDContextEngine } from "./src/context/engine.js";
import type { ContextEngineConfig } from "./src/context/engine.js";

const gspdContextPlugin = {
  id: "context-gspd",
  name: "GsPD Context Engine",
  description:
    "Token budget management, compression, and context assembly, backed by C/SQLite engine via MCP",
  kind: "context-engine" as const,
  configSchema: gspdContextConfigSchema,

  register(api: OpenClawPluginApi) {
    const cfg = gspdContextConfigSchema.parse(api.pluginConfig);
    const resolvedDbPath = api.resolvePath(cfg.dbPath);

    const clientEnv: Record<string, string> = {
      OPENAI_EMBED_BASE_URL: cfg.embed.baseUrl,
      OPENAI_EMBED_API_KEY: cfg.embed.apiKey,
      OPENAI_EMBED_MODEL: cfg.embed.model,
      OPENAI_CHAT_BASE_URL: cfg.chat.baseUrl,
      OPENAI_CHAT_API_KEY: cfg.chat.apiKey,
      OPENAI_CHAT_MODEL: cfg.chat.model,
    };

    if (cfg.vectorDim) {
      clientEnv.GSPD_VECTOR_DIM = String(cfg.vectorDim);
    }
    if (process.env.GSPD_VECTOR_DIM) {
      clientEnv.GSPD_VECTOR_DIM = process.env.GSPD_VECTOR_DIM;
    } else if (process.env.EMBED_DIM) {
      clientEnv.GSPD_VECTOR_DIM = process.env.EMBED_DIM;
    }

    // Shared client — reuses memory-plugin's MCP server process if already running
    const client = getOrCreateGspdClient(cfg.serverBinaryPath, resolvedDbPath, clientEnv);

    const engineCfg: ContextEngineConfig = {
      tokenBudget: cfg.tokenBudget,
      safetyMarginPct: cfg.safetyMarginPct,
      recentTurnsToKeep: cfg.recentTurnsToKeep,
      autoCompact: cfg.autoCompact,
      skill: cfg.skill,
    };

    if (cfg.skill?.enabled) {
      setSkillInjectViaContext(true);
      api.logger.info("context-gspd: skill inject via context engine enabled");
    }

    const engine = createGsPDContextEngine(api, client, cfg, engineCfg);
    api.logger.info("[DEBUG] context-gspd: calling registerContextEngine");
    api.registerContextEngine("context-gspd", () => {
      api.logger.info("[DEBUG] context-gspd: FACTORY CALLED!");
      return engine;
    });

    api.logger.info(
      `context-gspd: registered (shared client, db: ${resolvedDbPath})`,
    );
  },
};

export default gspdContextPlugin;
