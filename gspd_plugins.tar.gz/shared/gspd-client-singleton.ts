/**
 * Global singleton for GspdMcpClient — shared across memory-plugin and context-engine-plugin.
 *
 * Uses Symbol.for() + globalThis to ensure a single MCP server process
 * even when two independent plugins are loaded.
 */

import { GspdMcpClient } from "../memory-plugin/src/core/client.js";

const GSPD_CLIENT_KEY = Symbol.for("openclaw.gspd_mcp_client");
const GSPD_SESSIONS_KEY = Symbol.for("openclaw.gspd_active_sessions");
const GSPD_SKILL_INJECT_KEY = Symbol.for("openclaw.gspd_skill_inject_via_context");

type GspdClientState = {
  client: GspdMcpClient;
  refCount: number;
};

export type ActiveSessionState = {
  fragmentIds: number[];
  turnIds: number[];
  registeredSystemHashes: Set<string>;
};

/**
 * Get an existing shared client or create a new one.
 * First caller creates the client; subsequent callers reuse it.
 */
export function getOrCreateGspdClient(
  binaryPath: string,
  dbPath: string,
  env: Record<string, string>,
): GspdMcpClient {
  const g = globalThis as typeof globalThis & { [GSPD_CLIENT_KEY]?: GspdClientState };
  if (g[GSPD_CLIENT_KEY]) {
    g[GSPD_CLIENT_KEY].refCount++;
    // Merge env from later callers so that keys like GSPD_SKILLS_DIR
    // are available regardless of plugin registration order.
    g[GSPD_CLIENT_KEY].client.mergeEnv(env);
    return g[GSPD_CLIENT_KEY].client;
  }
  const client = new GspdMcpClient(binaryPath, dbPath, env);
  g[GSPD_CLIENT_KEY] = { client, refCount: 1 };
  return client;
}

/**
 * Release a reference to the shared client.
 * When refCount reaches 0, the MCP server process is closed.
 */
export function releaseGspdClient(): void {
  const g = globalThis as typeof globalThis & { [GSPD_CLIENT_KEY]?: GspdClientState };
  if (!g[GSPD_CLIENT_KEY]) return;
  g[GSPD_CLIENT_KEY].refCount--;
  if (g[GSPD_CLIENT_KEY].refCount <= 0) {
    g[GSPD_CLIENT_KEY].client.close();
    delete g[GSPD_CLIENT_KEY];
  }
}

/**
 * Get the shared active sessions map — persists across plugin re-registrations.
 * Uses globalThis so the same Map instance is reused even when register() is
 * called multiple times per agent turn by OpenClaw's plugin lifecycle.
 */
export function getSharedActiveSessionsMap(): Map<string, ActiveSessionState> {
  const g = globalThis as typeof globalThis & {
    [GSPD_SESSIONS_KEY]?: Map<string, ActiveSessionState>;
  };
  if (!g[GSPD_SESSIONS_KEY]) {
    g[GSPD_SESSIONS_KEY] = new Map();
  }
  return g[GSPD_SESSIONS_KEY];
}

/**
 * Signal that context engine is handling skill inject.
 * Called by context-engine-plugin when skill.enabled = true.
 */
export function setSkillInjectViaContext(enabled: boolean): void {
  const g = globalThis as typeof globalThis & { [GSPD_SKILL_INJECT_KEY]?: boolean };
  g[GSPD_SKILL_INJECT_KEY] = enabled;
}

/**
 * Check if context engine is handling skill inject.
 * Used by memory-plugin to skip its own before_prompt_build hook.
 */
export function isSkillInjectViaContext(): boolean {
  const g = globalThis as typeof globalThis & { [GSPD_SKILL_INJECT_KEY]?: boolean };
  return g[GSPD_SKILL_INJECT_KEY] === true;
}

export type { GspdMcpClient };
